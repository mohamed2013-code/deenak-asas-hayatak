import { hadiths, Hadith } from "./data/hadiths";

// دالة لتنظيف النص من التشكيل والهمزات لتسهيل البحث
function normalizeText(text: string): string {
  if (!text) return "";
  return text
    .replace(/[\u0617-\u061A\u064B-\u0652]/g, "") // إزالة التشكيل
    .replace(/[إأآا]/g, "ا") // توحيد الألفات
    .replace(/ؤ/g, "و")
    .replace(/ئ/g, "ي")
    .replace(/ة/g, "ه")
    .toLowerCase();
}

export function searchHadiths(query: string): Hadith[] {
  if (!query || query.trim() === "") {
    return hadiths;
  }

  const searchTerm = normalizeText(query);

  return hadiths.filter((hadith) => {
    const matchTitle = normalizeText(hadith.title).includes(searchTerm);
    const matchCategory = normalizeText(hadith.category).includes(searchTerm);
    const matchText = normalizeText(hadith.text).includes(searchTerm);
    const matchSource = normalizeText(hadith.source).includes(searchTerm);
    const matchBenefit = normalizeText(hadith.benefit).includes(searchTerm);

    return (
      matchTitle || matchCategory || matchText || matchSource || matchBenefit
    );
  });
}
