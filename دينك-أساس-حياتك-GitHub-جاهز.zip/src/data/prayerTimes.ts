export const prayerTimes = [
  { id: 'fajr', name: 'الفجر', time: '04:32' },
  { id: 'sunrise', name: 'الشروق', time: '05:58' },
  { id: 'dhuhr', name: 'الظهر', time: '12:14' },
  { id: 'asr', name: 'العصر', time: '15:47' },
  { id: 'maghrib', name: 'المغرب', time: '18:52' },
  { id: 'isha', name: 'العشاء', time: '20:22' },
];
