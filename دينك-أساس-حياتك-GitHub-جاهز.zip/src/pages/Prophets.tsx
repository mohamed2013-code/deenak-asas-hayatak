import { PageTransition } from "../components/PageTransition";
import { ProphetCard } from "../components/ProphetCard";
import { prophets } from "../data/prophets";
import { Search } from "lucide-react";
import { useState } from "react";
import { IslamicPattern } from "../components/IslamicPattern";

export default function Prophets() {
  const [searchTerm, setSearchTerm] = useState("");

  const filteredProphets = prophets.filter(prophet => 
    prophet.name.includes(searchTerm) || prophet.title.includes(searchTerm)
  );

  return (
    <PageTransition className="p-4 md:p-8 flex flex-col gap-6">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 bg-primary/5 p-6 rounded-3xl relative overflow-hidden border border-primary/10">
        <IslamicPattern opacity={0.05} />
        <div className="relative z-10">
          <h1 className="text-3xl font-bold text-foreground mb-2">الأنبياء والرسل</h1>
          <p className="text-muted-foreground">أُولَٰئِكَ الَّذِينَ هَدَى اللَّهُ ۖ فَبِهُدَاهُمُ اقْتَدِهْ</p>
        </div>
        
        <div className="relative max-w-sm w-full z-10">
          <div className="absolute inset-y-0 right-3 flex items-center pointer-events-none">
            <Search className="w-5 h-5 text-muted-foreground" />
          </div>
          <input
            type="text"
            placeholder="ابحث باسم النبي أو لقبه..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-card/80 backdrop-blur-md border border-border rounded-xl py-3 pr-10 pl-4 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all"
            dir="rtl"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 mt-4 pb-20 md:pb-0">
        {filteredProphets.length > 0 ? (
          filteredProphets.map((prophet, index) => (
            <ProphetCard key={prophet.id} prophet={prophet} index={index} />
          ))
        ) : (
          <div className="col-span-full py-12 text-center text-muted-foreground bg-card rounded-2xl border border-dashed border-border">
            لم يتم العثور على نتائج مطابقة لبحثك
          </div>
        )}
      </div>
    </PageTransition>
  );
}
