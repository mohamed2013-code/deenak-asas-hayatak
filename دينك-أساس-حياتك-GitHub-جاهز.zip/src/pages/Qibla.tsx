import { PageTransition } from "../components/PageTransition";
import { Navigation } from "lucide-react";
import { useState, useEffect, useRef } from "react";

export default function Qibla() {
  const [started, setStarted] = useState<boolean>(false);
  const [showCalibration, setShowCalibration] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const [statusText, setStatusText] = useState<string>(
    "جارٍ تشغيل الحساسات...",
  );
  const [degreeText, setDegreeText] = useState<string>("--°");
  const [distanceText, setDistanceText] = useState<string>("--");
  const [directionText, setDirectionText] = useState<string>("--");

  const [arrowStyle, setArrowStyle] = useState<any>({
    left: "50%",
    opacity: 0,
    transform: "translate(-50%,-50%) rotate(0deg)",
  });
  const [statusStyle, setStatusStyle] = useState<any>({});

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const cameraStreamRef = useRef<MediaStream | null>(null);
  const orientationSamplesRef = useRef<number[]>([]);
  const lastGoodHeadingRef = useRef<number | null>(null);

  const KAABA_LAT = 21.4224779;
  const KAABA_LON = 39.8251832;

  const rad = (x: number) => (x * Math.PI) / 180;
  const deg = (x: number) => (x * 180) / Math.PI;

  const normalize = (angle: number) => {
    angle %= 360;
    if (angle < 0) angle += 360;
    return angle;
  };

  const angleDifference = (target: number, current: number) => {
    let diff = normalize(target - current);
    if (diff > 180) diff -= 360;
    return diff;
  };

  const calculateQibla = (lat: number, lon: number) => {
    const lat1 = rad(lat);
    const lat2 = rad(KAABA_LAT);
    const deltaLon = rad(KAABA_LON - lon);

    const y = Math.sin(deltaLon) * Math.cos(lat2);
    const x =
      Math.cos(lat1) * Math.sin(lat2) -
      Math.sin(lat1) * Math.cos(lat2) * Math.cos(deltaLon);

    return normalize(deg(Math.atan2(y, x)));
  };

  const calculateDistance = (
    lat1: number,
    lon1: number,
    lat2: number,
    lon2: number,
  ) => {
    const R = 6371;
    const p1 = rad(lat1);
    const p2 = rad(lat2);
    const dp = rad(lat2 - lat1);
    const dl = rad(lon2 - lon1);

    const a =
      Math.sin(dp / 2) ** 2 +
      Math.cos(p1) * Math.cos(p2) * Math.sin(dl / 2) ** 2;
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  };

  const getDirection = (angle: number) => {
    const names = [
      "شمال",
      "شمال شرق",
      "شرق",
      "جنوب شرق",
      "جنوب",
      "جنوب غرب",
      "غرب",
      "شمال غرب",
    ];
    return names[Math.round(normalize(angle) / 45) % 8];
  };

  let qiblaBearingCache: number | null = null;

  const getLocation = () => {
    return new Promise<void>((resolve, reject) => {
      if (!navigator.geolocation) {
        reject(new Error("المتصفح لا يدعم تحديد الموقع."));
        return;
      }

      setStatusText("📍 جارٍ تحديد موقعك...");

      navigator.geolocation.getCurrentPosition(
        (position) => {
          const userLat = position.coords.latitude;
          const userLon = position.coords.longitude;

          const qibla = calculateQibla(userLat, userLon);
          qiblaBearingCache = qibla;

          const km = calculateDistance(userLat, userLon, KAABA_LAT, KAABA_LON);
          setDistanceText(
            km >= 1000 ? Math.round(km) + " كم" : km.toFixed(1) + " كم",
          );
          setDegreeText(Math.round(qibla) + "°");
          setDirectionText(getDirection(qibla));

          resolve();
        },
        (error) => {
          let message = "تعذر تحديد موقعك.";
          if (error.code === 1)
            message =
              "تم رفض صلاحية الموقع. افتح إعدادات المتصفح واسمح للموقع باستخدام موقعك.";
          else if (error.code === 2)
            message = "تعذر الحصول على موقعك. تأكد من تشغيل GPS.";
          else if (error.code === 3)
            message = "انتهت مهلة تحديد الموقع. حاول مرة أخرى.";
          reject(new Error(message));
        },
        { enableHighAccuracy: true, timeout: 20000, maximumAge: 0 },
      );
    });
  };

  const startCamera = async () => {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      throw new Error(
        "المتصفح لا يسمح باستخدام الكاميرا. تأكد أن الموقع يعمل عبر HTTPS.",
      );
    }

    const stream = await navigator.mediaDevices.getUserMedia({
      video: {
        facingMode: { ideal: "environment" },
        width: { ideal: 1920 },
        height: { ideal: 1080 },
      },
      audio: false,
    });

    cameraStreamRef.current = stream;
    if (videoRef.current) {
      videoRef.current.srcObject = stream;
      await videoRef.current.play();
    }
  };

  const requestOrientationPermission = async () => {
    if (typeof (DeviceOrientationEvent as any) === "undefined") {
      throw new Error("هذا الجهاز أو المتصفح لا يوفر حساس الاتجاه.");
    }

    if (
      typeof (DeviceOrientationEvent as any).requestPermission === "function"
    ) {
      let permission;
      try {
        permission = await (DeviceOrientationEvent as any).requestPermission(
          true,
        );
      } catch (e) {
        permission = await (DeviceOrientationEvent as any).requestPermission();
      }
      if (permission !== "granted") {
        throw new Error("لم يتم السماح باستخدام حساس الاتجاه.");
      }
    }

    startOrientationListeners();
  };

  const startOrientationListeners = () => {
    window.addEventListener(
      "deviceorientationabsolute",
      handleOrientation,
      true,
    );
    window.addEventListener("deviceorientation", handleOrientation, true);
  };

  const handleOrientation = (event: any) => {
    let heading = null;

    if (typeof event.webkitCompassHeading === "number") {
      heading = event.webkitCompassHeading;
    } else if (event.absolute === true && typeof event.alpha === "number") {
      heading = 360 - event.alpha;
    } else if (typeof event.alpha === "number") {
      heading = 360 - event.alpha;
    }

    if (typeof heading !== "number" || !Number.isFinite(heading)) return;

    heading = normalize(heading);
    lastGoodHeadingRef.current = heading;

    orientationSamplesRef.current.push(heading);
    if (orientationSamplesRef.current.length > 12) {
      orientationSamplesRef.current.shift();
    }

    const currentHeading = circularAverage(orientationSamplesRef.current);
    updateAR(currentHeading);
  };

  const circularAverage = (values: number[]) => {
    if (!values.length) return null;
    let sinSum = 0;
    let cosSum = 0;

    values.forEach((angle) => {
      sinSum += Math.sin(rad(angle));
      cosSum += Math.cos(rad(angle));
    });

    return normalize(deg(Math.atan2(sinSum, cosSum)));
  };

  const updateAR = (currentHeading: number | null) => {
    if (qiblaBearingCache === null || currentHeading === null) return;

    const relative = angleDifference(qiblaBearingCache, currentHeading);
    const screenAngle = relative;

    let leftPos = "50%";
    let opacity = "1";

    if (Math.abs(relative) > 75) {
      leftPos = relative > 0 ? "88%" : "12%";
      opacity = "0.75";
    } else {
      let x = 50 + (relative / 75) * 42;
      x = Math.max(8, Math.min(92, x));
      leftPos = x + "%";
      opacity = "1";
    }

    setArrowStyle({
      left: leftPos,
      opacity: opacity,
      transform: `translate(-50%,-50%) rotate(${screenAngle}deg)`,
    });

    if (Math.abs(relative) < 5) {
      setStatusText("أنت تواجه القبلة");
      setStatusStyle({ background: "rgba(20,120,75,.85)" });
    } else if (Math.abs(relative) < 15) {
      setStatusText("اقتربت من اتجاه القبلة");
      setStatusStyle({ background: "rgba(80,75,20,.85)" });
    } else {
      setStatusText(
        relative > 0 ? "أدر الهاتف إلى اليمين ←" : "أدر الهاتف إلى اليسار →",
      );
      setStatusStyle({ background: "rgba(0,0,0,.55)" });
    }
  };

  const startApp = async () => {
    setErrorMessage(null);
    try {
      await getLocation();
      setStatusText("📷 جارٍ تشغيل الكاميرا...");
      await startCamera();
      setStatusText("🧭 جارٍ تفعيل البوصلة...");
      await requestOrientationPermission();

      setStarted(true);
      setTimeout(() => {
        setShowCalibration(true);
      }, 800);
    } catch (error: any) {
      console.error(error);
      setErrorMessage(error.message || "حدث خطأ أثناء تشغيل الأداة.");
    }
  };

  useEffect(() => {
    return () => {
      if (cameraStreamRef.current) {
        cameraStreamRef.current.getTracks().forEach((track) => track.stop());
      }
    };
  }, []);

  return (
    <PageTransition className="relative w-full min-h-[calc(100vh-80px)] flex flex-col items-center justify-center overflow-hidden bg-[#061820] text-white">
      {/* شاشة البداية */}
      {!started && (
        <div className="absolute inset-0 z-50 flex items-center justify-center p-6 bg-[radial-gradient(circle_at_50%_15%,#155568_0%,#082f3b_42%,#03161c_100%)]">
          <div className="w-full max-w-md text-center p-8 rounded-[30px] bg-white/10 border border-white/15 backdrop-blur-xl shadow-2xl">
            <div className="text-6xl mb-4">🕋</div>
            <h1 className="text-2xl font-bold mb-3">محدد القبلة AR</h1>
            <p className="text-[#c5dce1] text-xs leading-relaxed mb-6">
              استخدم الكاميرا والبوصلة لتحديد اتجاه القبلة من موقعك الحالي
              بطريقة تفاعلية.
              <br />
              <br />
              سنحتاج إلى إذن الموقع والكاميرا وحساسات الاتجاه.
            </p>

            {errorMessage && (
              <div className="mb-4 p-3 rounded-xl bg-red-950/80 border border-red-500/30 text-red-200 text-xs leading-relaxed">
                {errorMessage}
              </div>
            )}

            <button
              onClick={startApp}
              className="w-full py-4 bg-[#f4c95d] hover:bg-amber-400 text-[#092a32] font-bold text-base rounded-2xl transition-all shadow-lg cursor-pointer"
            >
              ابدأ تحديد القبلة
            </button>

            <div className="mt-4 text-[11px] text-[#8eafb6] leading-relaxed">
              للحصول على أفضل نتيجة استخدم الموقع من هاتفك عبر اتصال HTTPS،
              وأبعد الهاتف عن المعادن والأجهزة المغناطيسية.
            </div>
          </div>
        </div>
      )}

      {/* شاشة الواقع المعزز AR */}
      {started && (
        <div className="absolute inset-0 overflow-hidden bg-black">
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted
            className="absolute inset-0 w-full h-full object-cover z-10"
          />

          <div className="absolute inset-0 z-20 pointer-events-none">
            {/* الشريط العلوي */}
            <div className="absolute top-0 left-0 right-0 p-4 pt-[max(15px,env(safe-area-inset-top))] bg-gradient-to-b from-black/70 to-transparent">
              <div className="text-center font-bold text-lg flex items-center justify-center gap-2">
                <Navigation className="w-5 h-5 text-amber-400" />
                اتجاه القبلة
              </div>
              <div
                style={statusStyle}
                className="mx-auto mt-2 w-max max-w-[90%] px-3.5 py-2 rounded-full bg-black/55 backdrop-blur-md text-xs text-[#e9f5f7] text-center transition-colors"
              >
                {statusText}
              </div>
            </div>

            {/* مؤشر القبلة */}
            <div
              className="absolute top-1/2 w-[190px] h-[240px] text-center transition-[transform,opacity] duration-100"
              style={{
                left: arrowStyle.left,
                opacity: arrowStyle.opacity,
                transform: arrowStyle.transform,
                transformOrigin: "center center",
                filter: "drop-shadow(0 5px 12px rgba(0,0,0,.5))",
              }}
            >
              <div className="absolute left-1/2 top-0 -translate-x-1/2 w-0 h-0 border-x-[27px] border-x-transparent border-b-[48px] border-b-[#f4c95d]" />
              <div className="absolute left-1/2 top-[20px] -translate-x-1/2 w-[7px] h-[185px] rounded-[10px] bg-gradient-to-b from-[#ffe27a] to-[#f4c95d]" />
              <div className="absolute left-1/2 bottom-0 -translate-x-1/2 w-[60px] h-[60px] rounded-full bg-[#f4c95d]/95 text-[#142a2f] flex items-center justify-center text-3xl shadow-xl">
                🕋
              </div>
              <div className="absolute left-1/2 top-[255px] -translate-x-1/2 whitespace-nowrap bg-black/65 px-3.5 py-2 rounded-full text-xs font-bold">
                اتجاه القبلة
              </div>
            </div>

            {/* نقطة المنتصف */}
            <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-2.5 h-2.5 rounded-full bg-white shadow-[0_0_0_4px_rgba(255,255,255,0.2),0_0_15px_rgba(255,255,255,0.8)]" />

            {/* لوحة المعلومات السفلية */}
            <div className="absolute left-3 right-3 bottom-0 z-30 pb-[max(15px,env(safe-area-inset-bottom))] bg-gradient-to-t from-black/85 to-transparent">
              <div className="max-w-[500px] mx-auto p-4 rounded-[22px] bg-[#041b22]/85 border border-white/12 backdrop-blur-md">
                <div className="text-3xl font-bold text-center">
                  {degreeText}
                </div>
                <div className="text-center text-[#aacbd1] text-[11px] mt-1">
                  زاوية القبلة من الشمال الحقيقي
                </div>

                <div className="grid grid-cols-2 gap-2 mt-3">
                  <div className="bg-white/7 p-2.5 rounded-xl text-center">
                    <div className="text-[10px] text-[#9bbcc3] mb-1">
                      المسافة إلى الكعبة
                    </div>
                    <div className="text-xs font-bold">{distanceText}</div>
                  </div>
                  <div className="bg-white/7 p-2.5 rounded-xl text-center">
                    <div className="text-[10px] text-[#9bbcc3] mb-1">
                      الاتجاه
                    </div>
                    <div className="text-xs font-bold">{directionText}</div>
                  </div>
                </div>
              </div>
            </div>

            {/* نافذة المعايرة */}
            {showCalibration && (
              <div className="absolute z-50 left-5 right-5 top-1/2 -translate-y-1/2 p-6 text-center rounded-[25px] bg-[#04191f]/95 border border-white/15 backdrop-blur-xl pointer-events-auto">
                <div className="text-5xl mb-2">🧭</div>
                <h2 className="text-lg font-bold mb-2">عاير البوصلة</h2>
                <p className="text-[#b8d0d5] text-xs leading-relaxed mb-4">
                  حرّك الهاتف ببطء في شكل رقم 8 عدة مرات، ثم وجّه الهاتف في
                  الاتجاهات المختلفة.
                </p>
                <button
                  onClick={() => {
                    setShowCalibration(false);
                    setStatusText("حرّك الهاتف ببطء لتحديد القبلة.");
                  }}
                  className="w-full py-3.5 bg-[#f4c95d] hover:bg-amber-400 text-[#092a32] font-bold text-sm rounded-xl transition-all shadow-lg cursor-pointer"
                >
                  فهمت
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </PageTransition>
  );
}
