import React, { useState, useEffect } from "react";
import { hadiths, interactiveHadiths } from "../data/hadiths";

export default function HadithPage() {
  const [activeTab, setActiveTab] = useState<"nawawi" | "questions">("nawawi");
  const [memorized, setMemorized] = useState<{ [key: string]: boolean }>({});

  useEffect(() => {
    const saved = localStorage.getItem("memorized_hadiths");
    if (saved) {
      try {
        setMemorized(JSON.parse(saved));
      } catch (e) {
        console.error(e);
      }
    }
  }, []);

  const toggleMemorized = (id: string) => {
    const updated = { ...memorized, [id]: !memorized[id] };
    setMemorized(updated);
    localStorage.setItem("memorized_hadiths", JSON.stringify(updated));
  };

  const memorizedCount = Object.values(memorized).filter(Boolean).length;

  return (
    <div className="p-6 max-w-4xl mx-auto" dir="rtl">
      <h1 className="text-3xl font-bold mb-2 text-center text-emerald-800">
        طمئن قلبك
      </h1>
      <p className="text-center text-gray-500 mb-6">
        الأحاديث المحفوظة:{" "}
        <span className="font-bold text-emerald-600">{memorizedCount}</span> من{" "}
        {hadiths.length}
      </p>

      {/* أزرار التنقل بين الأربعين النووية والأسئلة النبوية التفاعلية */}
      <div className="flex justify-center gap-4 mb-8">
        <button
          onClick={() => setActiveTab("nawawi")}
          className={`px-6 py-2.5 rounded-full font-medium transition-all ${
            activeTab === "nawawi"
              ? "bg-emerald-600 text-white shadow-md"
              : "bg-gray-100 text-gray-700 hover:bg-gray-200"
          }`}
        >
          الأربعون النووية (42 حديثاً)
        </button>
        <button
          onClick={() => setActiveTab("questions")}
          className={`px-6 py-2.5 rounded-full font-medium transition-all ${
            activeTab === "questions"
              ? "bg-emerald-600 text-white shadow-md"
              : "bg-gray-100 text-gray-700 hover:bg-gray-200"
          }`}
        >
          هل تريد؟ (11 سؤالاً واطمئنان)
        </button>
      </div>

      {/* عرض محتوى الأربعين النووية مع زر الحفظ */}
      {activeTab === "nawawi" && (
        <div className="space-y-4">
          {hadiths.map((h) => {
            const isSaved = !!memorized[h.id];
            return (
              <div
                key={h.id}
                className={`p-5 bg-white shadow rounded-xl border transition-all ${
                  isSaved
                    ? "border-emerald-500 bg-emerald-50/20"
                    : "border-gray-100"
                }`}
              >
                <div className="flex justify-between items-start gap-4">
                  <div>
                    <h2 className="text-xl font-semibold text-emerald-700">
                      {h.title}
                    </h2>
                    <p className="text-gray-500 text-sm mt-1">{h.source}</p>
                  </div>
                  <button
                    onClick={() => toggleMemorized(h.id)}
                    className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-all flex items-center gap-1.5 ${
                      isSaved
                        ? "bg-emerald-600 text-white shadow"
                        : "bg-gray-100 text-gray-600 hover:bg-emerald-100 hover:text-emerald-800"
                    }`}
                  >
                    {isSaved ? "✓ حفظت هذا الحديث" : "⭐ حفظت هذا الحديث"}
                  </button>
                </div>
                <p className="text-gray-800 mt-3 font-medium leading-relaxed">
                  {h.text}
                </p>
                <div className="mt-3 p-3 bg-emerald-50 rounded-lg text-emerald-900 text-sm">
                  <strong>اللطيفة / التأمل:</strong> {h.reflection}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* عرض محتوى الـ 11 حديث التفاعلي في تبويب الأسئلة */}
      {activeTab === "questions" && (
        <div className="space-y-4">
          {interactiveHadiths.map((item) => (
            <div
              key={item.id}
              className="p-5 bg-white shadow rounded-xl border border-emerald-50"
            >
              <span className="inline-block px-3 py-1 bg-emerald-100 text-emerald-800 text-xs font-semibold rounded-full mb-2">
                {item.category}
              </span>
              <h2 className="text-lg font-bold text-gray-900 mb-2">
                💡 {item.question}
              </h2>
              <p className="text-gray-800 mt-2 font-medium leading-relaxed bg-gray-50 p-3 rounded-lg border-r-4 border-emerald-500">
                {item.answer}
              </p>
              <p className="text-gray-400 text-xs mt-3 text-left">
                {item.source}
              </p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
