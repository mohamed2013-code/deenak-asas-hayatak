import { useNavigate, useParams } from "react-router-dom";
import { PageTransition } from "../components/PageTransition";
import { prophets } from "../data/prophets";
import { IslamicPattern } from "../components/IslamicPattern";
import { ArrowRight, BookOpen, Star, Info, Crown, MapPin, Clock } from "lucide-react";
import { motion } from "framer-motion";

export default function ProphetDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  
  const prophet = prophets.find(p => p.id === id);

  if (!prophet) {
    return (
      <div className="p-8 text-center flex flex-col items-center justify-center min-h-[50vh]">
        <h2 className="text-2xl font-bold mb-4">لم يتم العثور على النبي</h2>
        <button onClick={() => navigate('/prophets')} className="text-primary hover:underline">
          العودة للقائمة
        </button>
      </div>
    );
  }

  const sections = [
    { title: "النسب الشريف", content: prophet.lineage, icon: Star },
    { title: "النشأة والحياة", content: prophet.upbringing, icon: Info },
    { title: "رسالته ودعوته", content: prophet.mission, icon: BookOpen },
  ];

  return (
    <PageTransition className="p-4 md:p-8 flex flex-col gap-6 pb-24 md:pb-8">
      <button 
        onClick={() => navigate(-1)}
        className="self-start flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors bg-card px-4 py-2 rounded-full shadow-sm border border-border"
      >
        <ArrowRight className="w-4 h-4" />
        <span>الرجوع</span>
      </button>

      {/* Hero Section */}
      <div className="bg-primary text-primary-foreground rounded-3xl p-8 relative overflow-hidden shadow-xl shadow-primary/10">
        <IslamicPattern opacity={0.15} className="scale-150" />
        <div className="absolute top-0 right-0 w-64 h-64 bg-accent/20 rounded-full blur-3xl -translate-y-1/2 pointer-events-none"></div>
        
        <div className="relative z-10 flex flex-col items-center text-center">
          <div className="w-16 h-16 bg-accent/20 text-accent rounded-2xl flex items-center justify-center mb-6 transform rotate-45 shadow-inner">
            <div className="-rotate-45 font-bold text-2xl">{prophet.order}</div>
          </div>
          
          <h1 className="text-4xl md:text-5xl font-black mb-2 font-cairo tracking-tight">
            {prophet.name} <span className="text-2xl text-accent/80 font-normal">عليه السلام</span>
          </h1>
          <p className="text-xl md:text-2xl text-primary-foreground/90 font-medium mb-8">
            {prophet.title}
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 w-full max-w-3xl">
            <div className="bg-black/10 backdrop-blur-md rounded-2xl p-4 flex items-center gap-3">
              <Clock className="w-5 h-5 text-accent shrink-0" />
              <div className="text-right">
                <p className="text-xs text-primary-foreground/70 uppercase">الحقبة الزمنية</p>
                <p className="font-bold text-sm">{prophet.period}</p>
              </div>
            </div>
            <div className="bg-black/10 backdrop-blur-md rounded-2xl p-4 flex items-center gap-3">
              <MapPin className="w-5 h-5 text-accent shrink-0" />
              <div className="text-right">
                <p className="text-xs text-primary-foreground/70 uppercase">المكان/القوم</p>
                <p className="font-bold text-sm">{prophet.nation}</p>
              </div>
            </div>
            <div className="bg-black/10 backdrop-blur-md rounded-2xl p-4 flex items-center gap-3">
              <BookOpen className="w-5 h-5 text-accent shrink-0" />
              <div className="text-right">
                <p className="text-xs text-primary-foreground/70 uppercase">ذُكر في القرآن</p>
                <p className="font-bold text-sm">{prophet.quranMentions} مرة</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          {sections.map((section, idx) => (
            <motion.section 
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              className="bg-card border border-border rounded-3xl p-6 md:p-8"
            >
              <h2 className="text-2xl font-bold flex items-center gap-3 mb-4 text-foreground">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                  <section.icon className="w-5 h-5" />
                </div>
                {section.title}
              </h2>
              <p className="text-muted-foreground leading-relaxed text-lg whitespace-pre-line">
                {section.content}
              </p>
            </motion.section>
          ))}
        </div>

        {/* Sidebar Lists */}
        <div className="space-y-6">
          {/* Miracles */}
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-card border border-border rounded-3xl p-6"
          >
            <h3 className="text-xl font-bold flex items-center gap-2 mb-4 text-foreground">
              <Crown className="w-5 h-5 text-accent" />
              المعجزات الإلهية
            </h3>
            <ul className="space-y-3">
              {prophet.miracles.map((miracle, idx) => (
                <li key={idx} className="flex gap-3 text-muted-foreground leading-relaxed">
                  <span className="text-accent font-bold mt-1">•</span>
                  <span>{miracle}</span>
                </li>
              ))}
            </ul>
          </motion.div>

          {/* Lessons */}
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-primary/5 border border-primary/20 rounded-3xl p-6"
          >
            <h3 className="text-xl font-bold flex items-center gap-2 mb-4 text-primary">
              <Star className="w-5 h-5" />
              الدروس المستفادة
            </h3>
            <ul className="space-y-3">
              {prophet.lessons.map((lesson, idx) => (
                <li key={idx} className="flex gap-3 text-muted-foreground leading-relaxed">
                  <span className="w-6 h-6 rounded-full bg-primary/20 text-primary flex items-center justify-center text-xs shrink-0 mt-0.5 font-bold">
                    {idx + 1}
                  </span>
                  <span>{lesson}</span>
                </li>
              ))}
            </ul>
          </motion.div>
        </div>
      </div>

      {/* Main Verse */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="mt-4 bg-gradient-to-br from-card to-card border border-border rounded-3xl p-8 md:p-12 text-center relative overflow-hidden"
      >
        <IslamicPattern opacity={0.03} />
        <h3 className="text-sm font-bold text-primary uppercase tracking-wider mb-6 relative z-10">
          من القرآن الكريم
        </h3>
        <p className="text-2xl md:text-4xl font-cairo font-medium leading-loose text-foreground mb-6 relative z-10">
          ﴿ {prophet.mainVerse} ﴾
        </p>
        <p className="text-muted-foreground text-sm font-bold relative z-10">
          [{prophet.mainVerseRef}]
        </p>
      </motion.div>
    </PageTransition>
  );
}
