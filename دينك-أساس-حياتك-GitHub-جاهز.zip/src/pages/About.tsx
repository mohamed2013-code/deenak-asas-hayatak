import { PageTransition } from "../components/PageTransition";
import { IslamicPattern } from "../components/IslamicPattern";
import { Heart, Shield, Star, Users } from "lucide-react";

export default function About() {
  return (
    <PageTransition className="p-4 md:p-8 flex flex-col gap-8 max-w-4xl mx-auto w-full pb-24 md:pb-8">
      {/* Hero Section */}
      <div className="bg-primary text-primary-foreground rounded-3xl p-8 md:p-12 text-center relative overflow-hidden shadow-xl shadow-primary/10 mt-4 md:mt-0">
        <IslamicPattern opacity={0.1} />
        <div className="absolute top-0 right-0 w-48 h-48 bg-accent/20 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-background/10 rounded-full blur-3xl pointer-events-none"></div>
        
        <div className="relative z-10 flex flex-col items-center">
          <div className="w-20 h-20 bg-background rounded-full flex items-center justify-center mb-6 shadow-lg">
            <Heart className="w-10 h-10 text-primary" fill="currentColor" />
          </div>
          <h1 className="text-4xl md:text-5xl font-black font-cairo mb-4">طمئن قلبك</h1>
          <p className="text-lg md:text-xl text-primary-foreground/80 max-w-2xl mx-auto leading-relaxed">
            ملاذك الرقمي للسكينة والروحانية. صُمم ليكون رفيقك اليومي في رحلتك نحو طمأنينة القلب بذكر الله.
          </p>
        </div>
      </div>

      {/* Mission & Vision */}
      <div className="grid md:grid-cols-2 gap-6">
        <div className="bg-card border border-border rounded-3xl p-8 shadow-sm relative overflow-hidden">
          <div className="absolute top-0 right-0 w-24 h-24 bg-primary/5 rounded-bl-full pointer-events-none"></div>
          <Star className="w-8 h-8 text-primary mb-4" />
          <h3 className="text-2xl font-bold mb-4 font-cairo">رؤيتنا</h3>
          <p className="text-muted-foreground leading-loose">
            أن نكون التطبيق الإسلامي الأكثر تأثيراً في حياة المسلم اليومية، من خلال تقديم تجربة مستخدم نقية، هادئة، وخالية من المشتتات تعين على التركيز في العبادة.
          </p>
        </div>
        
        <div className="bg-card border border-border rounded-3xl p-8 shadow-sm relative overflow-hidden">
          <div className="absolute top-0 right-0 w-24 h-24 bg-accent/5 rounded-bl-full pointer-events-none"></div>
          <Shield className="w-8 h-8 text-accent mb-4" />
          <h3 className="text-2xl font-bold mb-4 font-cairo">قيمنا</h3>
          <p className="text-muted-foreground leading-loose">
            الإتقان في العمل، الأصالة في المحتوى، الجمال في التصميم، والخصوصية التامة للمستخدم. لا نقوم بجمع بياناتك ولا نعرض أي إعلانات مزعجة.
          </p>
        </div>
      </div>

      {/* The Team / Credits */}
      <div className="bg-card border border-border rounded-3xl p-8 shadow-sm text-center">
        <Users className="w-8 h-8 text-primary mx-auto mb-4" />
        <h3 className="text-2xl font-bold mb-8 font-cairo">فريق العمل</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            { role: "التصميم وتجربة المستخدم", desc: "تصميم واجهات ناعمة ومريحة للعين" },
            { role: "التطوير البرمجي", desc: "أداء سريع وتجربة خالية من الأخطاء" },
            { role: "المراجعة الشرعية", desc: "تدقيق المحتوى من مصادره الموثوقة" }
          ].map((item, i) => (
            <div key={i} className="p-6 bg-muted/50 rounded-2xl">
              <div className="w-12 h-12 bg-background border border-border rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold text-primary">
                {i + 1}
              </div>
              <h4 className="font-bold mb-2">{item.role}</h4>
              <p className="text-sm text-muted-foreground">{item.desc}</p>
            </div>
          ))}
        </div>
      </div>
      
      <div className="text-center py-8 border-t border-border">
        <p className="text-muted-foreground mb-2">"إِنَّ اللَّهَ يُحِبُّ إِذَا عَمِلَ أَحَدُكُمْ عَمَلًا أَنْ يُتْقِنَهُ"</p>
        <p className="text-sm font-medium">صدق رسول الله ﷺ</p>
      </div>
    </PageTransition>
  );
}
