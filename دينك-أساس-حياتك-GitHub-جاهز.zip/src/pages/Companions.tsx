import { PageTransition } from "../components/PageTransition";
import { companions } from "../data/companions";
import { Search } from "lucide-react";
import { useState } from "react";
import { CompanionCard } from "../components/CompanionCard";

const categories = [
  "الكل",
  "الخلفاء الراشدون",
  "العشرة المبشرون",
  "أمهات المؤمنين",
  "القادة والفاتحون",
  "العلماء والرواة",
  "الصحابيات",
];

export default function Companions() {
  const [searchTerm, setSearchTerm] = useState("");
  const [activeCategory, setActiveCategory] = useState("الكل");

  const filtered = companions.filter((comp) => {
    const matchesSearch =
      comp.name.includes(searchTerm) ||
      comp.title.includes(searchTerm) ||
      comp.fullName.includes(searchTerm);
    const matchesCategory =
      activeCategory === "الكل"
        ? true
        : activeCategory === "الخلفاء الراشدون"
          ? [
              "أبو بكر الصديق",
              "عمر بن الخطاب",
              "عثمان بن عفان",
              "علي بن أبي طالب",
            ].includes(comp.name)
          : comp.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <PageTransition className="p-4 md:p-8 flex flex-col gap-6">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 bg-card p-6 rounded-3xl border border-border shadow-sm">
        <div>
          <h1 className="text-3xl font-bold text-foreground mb-2">
            الصحابة الكرام
          </h1>
          <p className="text-muted-foreground">
            رَّضِيَ اللَّهُ عَنْهُمْ وَرَضُوا عَنْهُ
          </p>
        </div>

        <div className="relative max-w-sm w-full">
          <div className="absolute inset-y-0 right-3 flex items-center pointer-events-none">
            <Search className="w-5 h-5 text-muted-foreground" />
          </div>
          <input
            type="text"
            placeholder="ابحث باسم الصحابي أو لقبه..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-background border border-border rounded-xl py-3 pr-10 pl-4 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all"
            dir="rtl"
          />
        </div>
      </div>

      {/* Filter Chips */}
      <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={`whitespace-nowrap px-4 py-2 rounded-full text-sm font-bold transition-all ${
              activeCategory === cat
                ? "bg-primary text-primary-foreground shadow-md shadow-primary/20"
                : "bg-card text-muted-foreground border border-border hover:bg-muted"
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 mt-2 pb-20 md:pb-0">
        {filtered.length > 0 ? (
          filtered.map((companion, index) => (
            <CompanionCard
              key={companion.id}
              companion={companion}
              index={index}
            />
          ))
        ) : (
          <div className="col-span-full py-12 text-center text-muted-foreground bg-card rounded-2xl border border-dashed border-border">
            لم يتم العثور على نتائج مطابقة لبحثك
          </div>
        )}
      </div>
    </PageTransition>
  );
}
