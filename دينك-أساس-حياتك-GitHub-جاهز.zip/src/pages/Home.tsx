import { PageTransition } from "../components/PageTransition";
import { IslamicPattern } from "../components/IslamicPattern";
import { PrayerCard } from "../components/PrayerCard";
import { prayerTimes } from "../data/prayerTimes";
import { Link } from "react-router-dom";
import { Heart, BookOpen, Clock, Compass, Hand, Quote, Star, Users, Sparkles } from "lucide-react";
import { motion } from "framer-motion";

export default function Home() {
  const quickLinks = [
    { path: "/quran",     label: "القرآن",          icon: BookOpen, color: "bg-teal-500/10 text-teal-600 dark:text-teal-400"   },
    { path: "/adhkar",    label: "الأذكار",          icon: Heart,    color: "bg-rose-500/10 text-rose-600 dark:text-rose-400"   },
    { path: "/adiyah",    label: "الأدعية",          icon: Hand,     color: "bg-blue-500/10 text-blue-600 dark:text-blue-400"   },
    { path: "/qibla",     label: "القبلة",           icon: Compass,  color: "bg-amber-500/10 text-amber-600 dark:text-amber-400"},
    { path: "/tasbih",    label: "التسبيح",          icon: Sparkles, color: "bg-purple-500/10 text-purple-600 dark:text-purple-400"},
    { path: "/prophets",  label: "الأنبياء والرسل",  icon: Star,     color: "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400"},
    { path: "/companions",label: "الصحابة الكرام",   icon: Users,    color: "bg-indigo-500/10 text-indigo-600 dark:text-indigo-400"},
    { path: "/prayer-times", label: "مواقيت الصلاة", icon: Clock,    color: "bg-sky-500/10 text-sky-600 dark:text-sky-400"     },
  ];

  return (
    <PageTransition className="p-4 md:p-8 flex flex-col gap-8">
      {/* Hero Section */}
      <section className="relative overflow-hidden rounded-3xl bg-primary text-primary-foreground shadow-xl shadow-primary/20 p-8 md:p-12 min-h-[300px] flex flex-col justify-center">
        <IslamicPattern opacity={0.1} />
        <div className="absolute -left-20 -top-20 w-64 h-64 bg-accent/20 rounded-full blur-3xl"></div>
        <div className="absolute -right-20 -bottom-20 w-64 h-64 bg-background/10 rounded-full blur-3xl"></div>
        
        <div className="relative z-10 flex flex-col items-center text-center space-y-6">
          <motion.div 
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="text-4xl md:text-6xl font-black leading-loose text-accent drop-shadow-sm font-cairo py-4"
          >
            بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ
          </motion.div>
          <p className="text-primary-foreground/80 max-w-lg text-lg">
            ألا بذكر الله تطمئن القلوب
          </p>
        </div>
      </section>

      {/* Quick Links Grid — 4 cols on desktop, 4 cols on mobile (2×4 then 2×4) */}
      <section>
        <h2 className="text-lg font-bold text-muted-foreground mb-4 flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-primary" />
          الوصول السريع
        </h2>
        <div className="grid grid-cols-4 md:grid-cols-4 gap-3">
          {quickLinks.map((link, i) => (
            <Link key={link.path} to={link.path}>
              <motion.div 
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: i * 0.06 }}
                whileHover={{ y: -4, scale: 1.03 }}
                className="bg-card border border-border rounded-2xl p-3 md:p-5 flex flex-col items-center justify-center gap-2 md:gap-3 hover:border-primary/30 hover:shadow-lg transition-all"
              >
                <div className={`p-2.5 md:p-3.5 rounded-xl md:rounded-2xl ${link.color}`}>
                  <link.icon className="w-5 h-5 md:w-7 md:h-7" />
                </div>
                <span className="font-bold text-foreground text-xs md:text-sm text-center leading-tight">{link.label}</span>
              </motion.div>
            </Link>
          ))}
        </div>
      </section>

      {/* Prayer Times Widget */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <Clock className="w-5 h-5 text-primary" />
            مواقيت الصلاة
          </h2>
          <Link to="/prayer-times" className="text-sm text-muted-foreground hover:text-primary transition-colors">
            عرض الكل
          </Link>
        </div>
        
        <div className="bg-card border border-border rounded-3xl p-6 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <div>
              <p className="text-muted-foreground text-sm">القاهرة، مصر</p>
              <p className="text-lg font-bold">٢٤ رمضان ١٤٤٥</p>
            </div>
            <div className="text-left">
              <p className="text-muted-foreground text-sm">الصلاة القادمة</p>
              <p className="text-xl font-black text-primary">- 01:24:45</p>
            </div>
          </div>
          
          <div className="grid grid-cols-3 md:grid-cols-6 gap-3">
            {prayerTimes.map((prayer) => (
              <PrayerCard 
                key={prayer.id}
                name={prayer.name}
                time={prayer.time}
                isNext={prayer.id === 'dhuhr'} 
              />
            ))}
          </div>
        </div>
      </section>

      {/* Daily Verse / Hadith */}
      <section className="grid md:grid-cols-2 gap-6">
        <div className="bg-card border border-border rounded-3xl p-6 shadow-sm relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-bl-full -z-0"></div>
          <Quote className="w-8 h-8 text-primary/20 absolute top-4 right-4" />
          
          <div className="relative z-10 space-y-4">
            <div className="inline-block px-3 py-1 bg-primary/10 text-primary text-xs font-bold rounded-full mb-2">
              آية اليوم
            </div>
            <p className="text-xl md:text-2xl font-medium leading-loose text-center py-4">
              "وَمَنْ يَتَّقِ اللَّهَ يَجْعَلْ لَهُ مَخْرَجًا * وَيَرْزُقْهُ مِنْ حَيْثُ لَا يَحْتَسِبُ"
            </p>
            <p className="text-sm text-muted-foreground text-left">سورة الطلاق (2-3)</p>
          </div>
        </div>

        <div className="bg-card border border-border rounded-3xl p-6 shadow-sm relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-accent/5 rounded-bl-full -z-0"></div>
          <Quote className="w-8 h-8 text-accent/20 absolute top-4 right-4" />
          
          <div className="relative z-10 space-y-4">
            <div className="inline-block px-3 py-1 bg-accent/10 text-accent-foreground dark:text-accent text-xs font-bold rounded-full mb-2">
              حديث اليوم
            </div>
            <p className="text-lg md:text-xl font-medium leading-loose text-center py-4">
              "كَلِمَتَانِ خَفِيفَتَانِ عَلَى اللِّسَانِ، ثَقِيلَتَانِ فِي الْمِيزَانِ، حَبِيبَتَانِ إِلَى الرَّحْمَنِ: سُبْحَانَ اللَّهِ وَبِحَمْدِهِ، سُبْحَانَ اللَّهِ الْعَظِيمِ."
            </p>
            <p className="text-sm text-muted-foreground text-left">متفق عليه</p>
          </div>
        </div>
      </section>
      
      {/* Decorative spacing at bottom */}
      <div className="h-8"></div>
    </PageTransition>
  );
}
