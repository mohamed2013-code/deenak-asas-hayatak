import { PageTransition } from "../components/PageTransition";
import { duaCategories, duaItems } from "../data/duas";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Hand, Heart, Copy, Share2 } from "lucide-react";
import { IslamicPattern } from "../components/IslamicPattern";

export default function Adiyah() {
  const [activeCategory, setActiveCategory] = useState<string>(duaCategories[0].id);
  const [likedDuas, setLikedDuas] = useState<Record<number, boolean>>({});

  const currentItems = duaItems[activeCategory] || [];

  const toggleLike = (id: number) => {
    setLikedDuas(prev => ({ ...prev, [id]: !prev[id] }));
  };

  return (
    <PageTransition className="p-4 md:p-8 flex flex-col gap-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground mb-2">الأدعية</h1>
        <p className="text-muted-foreground">وَقَالَ رَبُّكُمُ ادْعُونِي أَسْتَجِبْ لَكُمْ</p>
      </div>

      {/* Grid of Categories */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 mt-2">
        {duaCategories.map((category) => {
          const isActive = activeCategory === category.id;
          return (
            <button
              key={category.id}
              onClick={() => setActiveCategory(category.id)}
              className={`relative overflow-hidden p-4 rounded-2xl flex flex-col items-center justify-center gap-3 transition-all ${
                isActive
                  ? "bg-primary text-primary-foreground shadow-lg shadow-primary/20 scale-[1.02]"
                  : "bg-card text-muted-foreground border border-border hover:border-primary/30 hover:shadow-md"
              }`}
            >
              {isActive && <IslamicPattern opacity={0.1} />}
              <Hand className={`w-6 h-6 relative z-10 ${isActive ? "text-accent" : ""}`} />
              <span className="font-bold relative z-10 text-sm text-center">{category.title}</span>
            </button>
          );
        })}
      </div>

      {/* Duas List */}
      <div className="mt-6 space-y-6 pb-20 md:pb-0">
        {currentItems.length > 0 ? (
          <AnimatePresence mode="wait">
            <motion.div
              key={activeCategory}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
              className="space-y-6"
            >
              {currentItems.map((item) => (
                <div key={item.id} className="bg-card border border-border rounded-2xl p-6 relative overflow-hidden shadow-sm hover:shadow-md transition-shadow">
                  <div className="absolute top-0 right-0 w-24 h-24 bg-primary/5 rounded-bl-full pointer-events-none"></div>
                  
                  <p className="text-xl md:text-2xl font-medium leading-loose text-center text-foreground font-cairo py-6">
                    {item.text}
                  </p>
                  
                  <div className="flex items-center justify-between mt-6 pt-4 border-t border-border">
                    <span className="text-sm text-muted-foreground">{item.reference}</span>
                    
                    <div className="flex gap-2">
                      <button className="p-2 rounded-full hover:bg-muted text-muted-foreground transition-colors">
                        <Copy className="w-4 h-4" />
                      </button>
                      <button className="p-2 rounded-full hover:bg-muted text-muted-foreground transition-colors">
                        <Share2 className="w-4 h-4" />
                      </button>
                      <button 
                        onClick={() => toggleLike(item.id)}
                        className={`p-2 rounded-full transition-colors ${
                          likedDuas[item.id] ? "bg-accent/10 text-accent" : "hover:bg-muted text-muted-foreground"
                        }`}
                      >
                        <Heart className="w-4 h-4" fill={likedDuas[item.id] ? "currentColor" : "none"} />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </motion.div>
          </AnimatePresence>
        ) : (
          <div className="py-20 text-center text-muted-foreground bg-card rounded-3xl border border-dashed border-border flex flex-col items-center justify-center gap-4">
            <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center">
              <Hand className="w-8 h-8 opacity-50" />
            </div>
            <p>سيتم إضافة أدعية لهذا القسم قريباً</p>
          </div>
        )}
      </div>
    </PageTransition>
  );
}
