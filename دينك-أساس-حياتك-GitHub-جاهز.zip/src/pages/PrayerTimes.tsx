import { useState, useEffect, useRef } from "react";
import { PageTransition } from "../components/PageTransition";
import { Volume2, MapPin, Clock } from "lucide-react";

interface PrayerTime {
  name: string;
  time: string;
  key: string;
}

export default function PrayerTimes() {
  const [audioEnabled, setAudioEnabled] = useState(false);
  const [currentPrayerAlert, setCurrentPrayerAlert] = useState<string | null>(
    null,
  );
  const [prayers, setPrayers] = useState<PrayerTime[]>([]);
  const [locationName, setLocationName] = useState<string>(
    "جارٍ تحديد الموقع...",
  );
  const [nextPrayer, setNextPrayer] = useState<string>("--");

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const playedPrayersRef = useRef<{ [key: string]: string }>({});

  useEffect(() => {
    // ملف صوت الأذان (يمكنك استبداله برابط صوتي تفضله)
    audioRef.current = new Audio(
      "https://islamic-audio.s3.amazonaws.com/adhan.mp3",
    );
    audioRef.current.loop = false;

    // جلب أوقات الصلاة عند فتح الصفحة
    fetchPrayerTimes();

    // فحص الوقت كل 20 ثانية لمطابقة أوقات الصلاة وتشغيل الأذان
    const interval = setInterval(() => {
      checkPrayerTimesAndPlay();
    }, 20000);

    return () => clearInterval(interval);
  }, [audioEnabled, prayers]);

  const fetchPrayerTimes = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          const lat = position.coords.latitude;
          const lon = position.coords.longitude;

          try {
            const today = new Date();
            const dateStr = `${today.getDate()}-${today.getMonth() + 1}-${today.getFullYear()}`;

            // استخدام API مجاني دقيق لمواقيت الصلاة (Aladhan API)
            const response = await fetch(
              `https://api.aladhan.com/v1/timings/${dateStr}?latitude=${lat}&longitude=${lon}&method=5`,
            );
            const data = await response.json();

            if (data && data.data) {
              const timings = data.data.timings;
              const formattedPrayers: PrayerTime[] = [
                { name: "الفجر", time: timings.Fajr, key: "Fajr" },
                { name: "الشروق", time: timings.Sunrise, key: "Sunrise" },
                { name: "الظهر", time: timings.Dhuhr, key: "Dhuhr" },
                { name: "العصر", time: timings.Asr, key: "Asr" },
                { name: "المغرب", time: timings.Maghrib, key: "Maghrib" },
                { name: "العشاء", time: timings.Isha, key: "Isha" },
              ];
              setPrayers(formattedPrayers);
              setLocationName("موقعك الحالي");
            }
          } catch (e) {
            setDefaultPrayers();
          }
        },
        () => {
          setDefaultPrayers();
        },
        { timeout: 10000 },
      );
    } else {
      setDefaultPrayers();
    }
  };

  const setDefaultPrayers = () => {
    // مواعيد افتراضية احتياطية في حال تعذر الحصول على الموقع
    setPrayers([
      { name: "الفجر", time: "04:35", key: "Fajr" },
      { name: "الشروق", time: "06:05", key: "Sunrise" },
      { name: "الظهر", time: "12:50", key: "Dhuhr" },
      { name: "العصر", time: "16:20", key: "Asr" },
      { name: "المغرب", time: "19:15", key: "Maghrib" },
      { name: "العشاء", time: "20:45", key: "Isha" },
    ]);
    setLocationName("مكة المكرمة (افتراضي)");
  };

  const enableAutoAdhan = () => {
    setAudioEnabled(true);
    if (audioRef.current) {
      audioRef.current
        .play()
        .then(() => {
          audioRef.current?.pause();
          audioRef.current!.currentTime = 0;
        })
        .catch((e) => console.log("Audio permission needed", e));
    }
  };

  const checkPrayerTimesAndPlay = () => {
    if (!audioEnabled || prayers.length === 0) return;

    const now = new Date();
    const hours = String(now.getHours()).padStart(2, "0");
    const minutes = String(now.getMinutes()).padStart(2, "0");
    const currentTimeFormatted = `${hours}:${minutes}`;

    const todayDateStr = now.toDateString();

    prayers.forEach((prayer) => {
      // لا تشغيل أذان لوقت الشروق
      if (prayer.key === "Sunrise") return;

      // مقارنة الوقت (الساعة والدقيقة)
      if (prayer.time === currentTimeFormatted) {
        const playKey = `${todayDateStr}-${prayer.key}`;
        if (playedPrayersRef.current[playKey]) return; // منع تكرار التشغيل في نفس الدقيقة

        playedPrayersRef.current[playKey] = "played";
        playAdhan(prayer.name);
      }
    });
  };

  const playAdhan = (prayerName: string) => {
    if (audioRef.current && audioEnabled) {
      audioRef.current.currentTime = 0;
      audioRef.current
        .play()
        .then(() => {
          setCurrentPrayerAlert(`حان الآن وقت صلاة ${prayerName}`);
        })
        .catch((err) => console.log("تعذر تشغيل الأذان تلقائياً:", err));
    }
  };

  return (
    <PageTransition className="p-4 md:p-8 max-w-xl mx-auto text-white">
      <div className="bg-white/10 backdrop-blur-xl border border-white/15 rounded-[30px] p-6 shadow-2xl">
        {/* العنوان والموقع */}
        <div className="text-center mb-6">
          <h1 className="text-2xl font-bold mb-2">مواقيت الصلاة</h1>
          <div className="flex items-center justify-center gap-1.5 text-xs text-[#a2c4cb]">
            <MapPin className="w-3.5 h-3.5 text-amber-400" />
            <span>{locationName}</span>
          </div>
        </div>

        {/* زر تفعيل الأذان التلقائي */}
        {!audioEnabled ? (
          <button
            onClick={enableAutoAdhan}
            className="w-full bg-amber-400 hover:bg-amber-500 text-slate-950 font-bold py-3.5 px-4 rounded-xl text-sm transition-all shadow-lg flex items-center justify-center gap-2 cursor-pointer mb-6"
          >
            <Volume2 className="w-5 h-5" />
            تفعيل الأذان التلقائي في أوقات الصلاة
          </button>
        ) : (
          <div className="bg-emerald-950/80 border border-emerald-500/30 text-emerald-200 p-3 rounded-xl text-xs mb-6 flex items-center justify-center gap-2">
            <Volume2 className="w-4 h-4" />
            الأذان التلقائي مُفعل وجاهز للعمل في أوقاته
          </div>
        )}

        {/* تنبيه دخول وقت الصلاة */}
        {currentPrayerAlert && (
          <div className="bg-amber-500/20 border border-amber-400 text-amber-200 p-4 rounded-2xl mb-6 text-center animate-pulse">
            <p className="font-bold text-base">{currentPrayerAlert}</p>
          </div>
        )}

        {/* قائمة أوقات الصلاة */}
        <div className="space-y-3">
          {prayers.map((prayer, index) => (
            <div
              key={index}
              className="flex items-center justify-between p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md"
            >
              <div className="flex items-center gap-3">
                <Clock className="w-5 h-5 text-amber-400" />
                <span className="font-bold text-base">{prayer.name}</span>
              </div>
              <span
                className="font-mono text-lg text-amber-300 font-semibold"
                dir="ltr"
              >
                {prayer.time}
              </span>
            </div>
          ))}
        </div>
      </div>
    </PageTransition>
  );
}
