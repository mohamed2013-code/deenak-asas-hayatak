import { PageTransition } from "../components/PageTransition";
import { Mail, MessageSquare, Send, Phone, MapPin } from "lucide-react";
import { IslamicPattern } from "../components/IslamicPattern";

export default function Contact() {
  return (
    <PageTransition className="p-4 md:p-8 flex flex-col lg:flex-row gap-8 max-w-5xl mx-auto w-full pb-24 md:pb-8">
      {/* Contact Info */}
      <div className="w-full lg:w-1/3 space-y-6 mt-4 md:mt-0">
        <div>
          <h1 className="text-3xl font-bold text-foreground mb-2">اتصل بنا</h1>
          <p className="text-muted-foreground">نحن هنا للاستماع إلى مقترحاتك وملاحظاتك</p>
        </div>

        <div className="bg-primary text-primary-foreground rounded-3xl p-6 relative overflow-hidden shadow-lg shadow-primary/10 mt-8">
          <IslamicPattern opacity={0.1} />
          
          <div className="relative z-10 space-y-6">
            <h3 className="text-xl font-bold font-cairo mb-6 text-accent">معلومات التواصل</h3>
            
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 bg-primary-foreground/10 rounded-full flex items-center justify-center shrink-0">
                <Mail className="w-5 h-5" />
              </div>
              <div>
                <p className="text-sm text-primary-foreground/80 mb-1">البريد الإلكتروني</p>
                <p className="font-bold dir-ltr text-right">salam@tumaen.app</p>
              </div>
            </div>
            
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 bg-primary-foreground/10 rounded-full flex items-center justify-center shrink-0">
                <MessageSquare className="w-5 h-5" />
              </div>
              <div>
                <p className="text-sm text-primary-foreground/80 mb-1">الدعم الفني</p>
                <p className="font-bold dir-ltr text-right">support@tumaen.app</p>
              </div>
            </div>
          </div>
        </div>

        <div className="flex justify-center gap-4 pt-4">
          {/* Social placeholders */}
          {[1, 2, 3].map(i => (
            <div key={i} className="w-12 h-12 bg-card border border-border rounded-full flex items-center justify-center text-muted-foreground hover:text-primary hover:border-primary transition-colors cursor-pointer shadow-sm">
              <div className="w-5 h-5 bg-current rounded-sm opacity-50 mask-image-social"></div>
            </div>
          ))}
        </div>
      </div>

      {/* Contact Form */}
      <div className="w-full lg:w-2/3 bg-card border border-border rounded-3xl p-6 md:p-8 shadow-sm">
        <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
          <Send className="w-6 h-6 text-primary" />
          أرسل رسالة
        </h2>
        
        <form className="space-y-5" onSubmit={(e) => e.preventDefault()}>
          <div className="grid md:grid-cols-2 gap-5">
            <div className="space-y-2">
              <label htmlFor="name" className="text-sm font-bold text-foreground">الاسم الكريم</label>
              <input 
                type="text" 
                id="name"
                className="w-full bg-background border border-border rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all"
                placeholder="أدخل اسمك هنا..."
              />
            </div>
            <div className="space-y-2">
              <label htmlFor="email" className="text-sm font-bold text-foreground">البريد الإلكتروني</label>
              <input 
                type="email" 
                id="email"
                className="w-full bg-background border border-border rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all text-left"
                placeholder="email@example.com"
                dir="ltr"
              />
            </div>
          </div>
          
          <div className="space-y-2">
            <label htmlFor="subject" className="text-sm font-bold text-foreground">الموضوع</label>
            <select 
              id="subject"
              className="w-full bg-background border border-border rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all appearance-none"
            >
              <option value="">اختر موضوع الرسالة...</option>
              <option value="suggestion">اقتراح تطوير</option>
              <option value="bug">الإبلاغ عن مشكلة</option>
              <option value="partnership">شراكة أو تعاون</option>
              <option value="other">أخرى</option>
            </select>
          </div>
          
          <div className="space-y-2">
            <label htmlFor="message" className="text-sm font-bold text-foreground">نص الرسالة</label>
            <textarea 
              id="message"
              rows={5}
              className="w-full bg-background border border-border rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all resize-none"
              placeholder="اكتب رسالتك بالتفصيل هنا..."
            ></textarea>
          </div>
          
          <button 
            type="submit"
            className="w-full md:w-auto px-8 py-4 bg-primary text-primary-foreground rounded-xl font-bold hover:bg-primary/90 transition-colors shadow-md shadow-primary/20 flex items-center justify-center gap-2"
          >
            <span>إرسال الرسالة</span>
            <Send className="w-4 h-4 mr-2 rotate-180" />
          </button>
        </form>
      </div>
    </PageTransition>
  );
}
