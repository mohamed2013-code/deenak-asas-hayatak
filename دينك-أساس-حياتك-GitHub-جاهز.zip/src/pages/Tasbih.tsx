import { PageTransition } from "../components/PageTransition";
import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { RotateCcw, Volume2, VolumeX, Hand } from "lucide-react";
import { IslamicPattern } from "../components/IslamicPattern";

const TASBIH_PHRASES = [
  { text: "سُبْحَانَ اللَّهِ", target: 33 },
  { text: "الْحَمْدُ لِلَّهِ", target: 33 },
  { text: "اللَّهُ أَكْبَرُ", target: 34 }
];

export default function Tasbih() {
  const [count, setCount] = useState(0);
  const [totalCount, setTotalCount] = useState(0);
  const [phraseIndex, setPhraseIndex] = useState(0);
  const [soundEnabled, setSoundEnabled] = useState(true);

  const currentPhrase = TASBIH_PHRASES[phraseIndex];
  const progress = (count / currentPhrase.target) * 100;

  const handleTap = () => {
    // Vibrate if supported
    if (window.navigator && window.navigator.vibrate) {
      window.navigator.vibrate(50);
    }

    if (count < currentPhrase.target - 1) {
      setCount(prev => prev + 1);
    } else {
      // Finished current phrase
      if (window.navigator && window.navigator.vibrate) {
        window.navigator.vibrate([100, 50, 100]); // Special vibration for completion
      }
      setCount(0);
      setPhraseIndex(prev => (prev + 1) % TASBIH_PHRASES.length);
    }
    setTotalCount(prev => prev + 1);
  };

  const handleReset = () => {
    setCount(0);
    setTotalCount(0);
    setPhraseIndex(0);
  };

  return (
    <PageTransition className="p-4 md:p-8 flex flex-col gap-6 items-center min-h-[calc(100vh-100px)]">
      <div className="w-full flex justify-between items-start mb-4">
        <div>
          <h1 className="text-3xl font-bold text-foreground mb-2">السبحة الإلكترونية</h1>
          <p className="text-muted-foreground">وَالْبَاقِيَاتُ الصَّالِحَاتُ خَيْرٌ عِندَ رَبِّكَ</p>
        </div>
        
        <div className="flex gap-2">
          <button 
            onClick={() => setSoundEnabled(!soundEnabled)}
            className="p-3 bg-card border border-border rounded-full text-muted-foreground hover:text-foreground hover:bg-muted transition-colors shadow-sm"
          >
            {soundEnabled ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
          </button>
          <button 
            onClick={handleReset}
            className="p-3 bg-card border border-border rounded-full text-muted-foreground hover:text-foreground hover:bg-muted transition-colors shadow-sm"
          >
            <RotateCcw className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center w-full max-w-md pb-10">
        
        {/* Current Phrase Display */}
        <div className="bg-card border border-border rounded-3xl p-8 w-full text-center shadow-md relative overflow-hidden mb-12">
          <IslamicPattern className="text-primary" opacity={0.05} />
          
          <AnimatePresence mode="wait">
            <motion.div
              key={phraseIndex}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="relative z-10"
            >
              <h2 className="text-4xl md:text-5xl font-black text-primary font-cairo mb-4 leading-tight">
                {currentPhrase.text}
              </h2>
              <div className="inline-block bg-muted px-4 py-1.5 rounded-full text-sm font-bold text-muted-foreground">
                الهدف: {currentPhrase.target}
              </div>
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Big Tap Button */}
        <div className="relative">
          {/* Progress Ring */}
          <svg className="absolute inset-0 w-full h-full -rotate-90 pointer-events-none" viewBox="0 0 320 320">
            <circle 
              cx="160" cy="160" r="140" 
              className="stroke-muted/30" 
              strokeWidth="8" fill="none" 
            />
            <motion.circle 
              cx="160" cy="160" r="140" 
              className="stroke-primary" 
              strokeWidth="12" 
              fill="none" 
              strokeLinecap="round"
              initial={{ strokeDasharray: "0 1000" }}
              animate={{ 
                strokeDasharray: `${(progress / 100) * (2 * Math.PI * 140)} 1000` 
              }}
              transition={{ type: "spring", stiffness: 50 }}
            />
          </svg>

          {/* The Button */}
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={handleTap}
            className="w-64 h-64 md:w-72 md:h-72 bg-card border-[12px] border-background rounded-full shadow-2xl flex flex-col items-center justify-center relative z-10 mx-auto"
            style={{ 
              boxShadow: "0 20px 50px -12px rgba(0,0,0,0.15), inset 0 10px 20px -5px rgba(0,0,0,0.05)" 
            }}
          >
            <span className="text-7xl font-black text-foreground font-cairo select-none">{count}</span>
            <span className="text-muted-foreground font-medium mt-2 flex items-center gap-2">
              <Hand className="w-4 h-4" /> انقر للسبحة
            </span>
          </motion.button>
        </div>

        <div className="mt-12 text-center">
          <p className="text-muted-foreground">المجموع الكلي اليوم</p>
          <p className="text-3xl font-bold text-foreground mt-1">{totalCount}</p>
        </div>
      </div>
    </PageTransition>
  );
}
