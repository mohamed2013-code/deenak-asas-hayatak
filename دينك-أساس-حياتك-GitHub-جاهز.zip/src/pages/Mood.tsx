import React, { useState } from "react";
import { PageTransition } from "../components/PageTransition";
import { Heart, Sparkles, BookOpen, MessageCircle } from "lucide-react";

export const moods = [
  {
    id: "happy",
    name: "سعيد",
    emoji: "😊",
    color: "bg-green-50 text-green-700 border-green-200 hover:bg-green-100",
  },
  {
    id: "sad",
    name: "حزين",
    emoji: "🌧️",
    color: "bg-blue-50 text-blue-700 border-blue-200 hover:bg-blue-100",
  },
  {
    id: "grateful",
    name: "ممتن",
    emoji: "🤍",
    color: "bg-pink-50 text-pink-700 border-pink-200 hover:bg-pink-100",
  },
  {
    id: "grateful-to-allah",
    name: "شاكر",
    emoji: "🤲",
    color: "bg-amber-50 text-amber-700 border-amber-200 hover:bg-amber-100",
  },
  {
    id: "anxious",
    name: "قلق",
    emoji: "⚡",
    color: "bg-purple-50 text-purple-700 border-purple-200 hover:bg-purple-100",
  },
  {
    id: "peaceful",
    name: "مطمئن",
    emoji: "🌿",
    color:
      "bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100",
  },
  {
    id: "exhausted",
    name: "مرهق",
    emoji: "🔋",
    color: "bg-orange-50 text-orange-700 border-orange-200 hover:bg-orange-100",
  },
  {
    id: "tired",
    name: "متعب",
    emoji: "🛌",
    color: "bg-stone-50 text-stone-700 border-stone-200 hover:bg-stone-100",
  },
  {
    id: "repentant",
    name: "تائب",
    emoji: "✨",
    color: "bg-teal-50 text-teal-700 border-teal-200 hover:bg-teal-100",
  },
  {
    id: "regretful",
    name: "نادم",
    emoji: "🍂",
    color: "bg-rose-50 text-rose-700 border-rose-200 hover:bg-rose-100",
  },
  {
    id: "hopeful",
    name: "متفائل",
    emoji: "☀️",
    color: "bg-yellow-50 text-yellow-700 border-yellow-200 hover:bg-yellow-100",
  },
  {
    id: "confused",
    name: "حائر",
    emoji: "💡",
    color: "bg-indigo-50 text-indigo-700 border-indigo-200 hover:bg-indigo-100",
  },
  {
    id: "patient",
    name: "صابر",
    emoji: "⛰️",
    color: "bg-cyan-50 text-cyan-700 border-cyan-200 hover:bg-cyan-100",
  },
  {
    id: "lonely",
    name: "وحيد",
    emoji: "🌙",
    color: "bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100",
  },
  {
    id: "nostalgic",
    name: "حنين",
    emoji: "💭",
    color: "bg-violet-50 text-violet-700 border-violet-200 hover:bg-violet-100",
  },
];

export default function MoodPage() {
  const [selectedMood, setSelectedMood] = useState<string | null>(null);

  const currentMoodData = moods.find((m) => m.id === selectedMood);

  return (
    <PageTransition>
      <div className="max-w-4xl mx-auto p-4 sm:p-6 space-y-6">
        <div className="text-center space-y-2">
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 flex items-center justify-center gap-2">
            <Heart className="w-7 h-7 text-emerald-600 fill-emerald-600" />
            بماذا تشعر اليوم؟
          </h1>
          <p className="text-gray-600 text-sm sm:text-base">
            اختر شعورك الحالي لنقترح عليك ما يلامس قلبك من آيات، أدعية، وأحاديث
            تناسب حالتك.
          </p>
        </div>

        {/* شبكة المشاعر الـ 15 */}
        <div className="grid grid-cols-3 sm:grid-cols-5 gap-3">
          {moods.map((mood) => (
            <button
              key={mood.id}
              onClick={() => setSelectedMood(mood.id)}
              className={`p-4 rounded-2xl border transition-all flex flex-col items-center justify-center gap-2 shadow-sm ${
                mood.color
              } ${
                selectedMood === mood.id
                  ? "ring-4 ring-emerald-600/30 scale-105 shadow-md border-emerald-600"
                  : "hover:scale-[1.02]"
              }`}
            >
              <span className="text-3xl">{mood.emoji}</span>
              <span className="font-bold text-sm sm:text-base">
                {mood.name}
              </span>
            </button>
          ))}
        </div>

        {/* قسم عرض المحتوى المقترح بناءً على الشعور المحدد */}
        {selectedMood && currentMoodData && (
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-emerald-100 shadow-xl space-y-6 animate-fadeIn">
            <div className="flex items-center gap-3 border-b pb-4">
              <span className="text-4xl">{currentMoodData.emoji}</span>
              <div>
                <h3 className="text-xl font-bold text-gray-900">
                  رسالة لقلبك وأنت تشعر بـ ({currentMoodData.name})
                </h3>
                <p className="text-sm text-gray-500">
                  تذكر أن لكل حال ذكره وآياته الخاصة
                </p>
              </div>
            </div>

            <div className="space-y-4">
              <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-200 text-emerald-900 space-y-2">
                <div className="flex items-center gap-2 font-bold text-emerald-800">
                  <BookOpen className="w-5 h-5" />
                  <span>آية من القرآن الكريم:</span>
                </div>
                <p className="text-lg leading-relaxed font-arabic">
                  {selectedMood === "anxious" || selectedMood === "exhausted"
                    ? "أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ (الرعد: 28)"
                    : "وَاصْبِرْ لِحُكْمِ رَبِّكَ فَإِنَّكَ بِأَعْيُنِنَا (الطور: 48)"}
                </p>
              </div>

              <div className="p-4 bg-amber-50 rounded-2xl border border-amber-200 text-amber-900 space-y-2">
                <div className="flex items-center gap-2 font-bold text-amber-800">
                  <Sparkles className="w-5 h-5" />
                  <span>دعاء مناسب:</span>
                </div>
                <p className="text-base leading-relaxed">
                  «اللهم إني أعوذ بك من الهم والحزن، والعجز والكسل، والبخل جبن،
                  وغلبة الدين وقرجال الرجال»
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </PageTransition>
  );
}
