import React, { useState } from "react";
import { Copy, Heart, Share2 } from "lucide-react";

const azkarData = [
  { id: 1, text: "سُبْحَانَ اللهِ وَبِحَمْدِهِ", count: 3 },
  {
    id: 2,
    text: "لَا إِلَهَ إِلَّا اللهُ وَحْدَهُ لَا شَرِيكَ لَهُ",
    count: 10,
  },
];

export default function AzkarPage() {
  return (
    <div className="p-6 space-y-6 text-right" dir="rtl">
      <h2 className="text-2xl font-bold text-emerald-800 dark:text-emerald-400 mb-6">
        أذكار الصباح
      </h2>
      <div className="grid gap-4">
        {azkarData.map((zikr) => (
          <ZikrCard key={zikr.id} zikr={zikr} />
        ))}
      </div>
    </div>
  );
}

function ZikrCard({ zikr }: { zikr: any }) {
  const [count, setCount] = useState(zikr.count);

  return (
    <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-emerald-100 dark:border-slate-800 shadow-sm">
      <p className="text-lg mb-4">{zikr.text}</p>
      <div className="flex items-center justify-between">
        <button
          onClick={() => setCount((prev: number) => Math.max(0, prev - 1))}
          className="bg-emerald-600 text-white px-6 py-2 rounded-full font-bold min-w-[60px]"
        >
          {count}
        </button>
        <div className="flex gap-3 text-emerald-600">
          <Copy size={20} className="cursor-pointer" />
          <Heart size={20} className="cursor-pointer" />
          <Share2 size={20} className="cursor-pointer" />
        </div>
      </div>
    </div>
  );
}
