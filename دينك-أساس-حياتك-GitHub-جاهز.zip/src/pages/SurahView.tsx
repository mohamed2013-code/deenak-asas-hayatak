import { useEffect, useState, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { PageTransition } from "../components/PageTransition";
import { surahs } from "../data/surahs";
import {
  Play,
  Pause,
  ChevronDown,
  ChevronUp,
  Settings,
  ArrowRight,
} from "lucide-react";
import { motion } from "framer-motion";

interface Ayah {
  number: number;
  text: string;
  numberInSurah: number;
  juz: number;
  manzil: number;
  page: number;
  ruku: number;
  hizbQuarter: number;
  sajda: boolean | object;
}

interface TafsirAyah {
  numberInSurah: number;
  text: string;
}

export default function SurahView() {
  const { id } = useParams();
  const navigate = useNavigate();
  const surahId = parseInt(id || "1", 10);

  const surahMeta = surahs.find((s) => s.id === surahId);

  const [ayahs, setAyahs] = useState<Ayah[]>([]);
  const [tafsirs, setTafsirs] = useState<TafsirsRecord>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Settings
  const [fontSize, setFontSize] = useState<number>(24);
  const [showAllTafsir, setShowAllTafsir] = useState(false);
  const [expandedTafsirs, setExpandedTafsirs] = useState<
    Record<number, boolean>
  >({});

  // Audio
  const [playingAyah, setPlayingAyah] = useState<number | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  type TafsirsRecord = Record<number, string>;

  useEffect(() => {
    // Load settings
    const savedSize = localStorage.getItem("quranFontSize");
    if (savedSize) setFontSize(parseInt(savedSize, 10));

    // Load Last Read
    localStorage.setItem(
      "lastRead",
      JSON.stringify({ surahId, timestamp: Date.now() }),
    );
  }, [surahId]);

  useEffect(() => {
    if (!surahMeta) {
      setError("السورة غير موجودة في قاعدة البيانات الحالية.");
      setLoading(false);
      return;
    }

    const fetchData = async () => {
      try {
        setLoading(true);
        setError(null);

        const [quranRes, tafsirRes] = await Promise.all([
          fetch(
            `https://api.alquran.cloud/v1/surah/${surahId}/editions/quran-uthmani`,
          ),
          fetch(
            `https://api.alquran.cloud/v1/surah/${surahId}/editions/ar.muyassar`,
          ),
        ]);

        const quranData = await quranRes.json();
        const tafsirData = await tafsirRes.json();

        if (quranData.code === 200 && tafsirData.code === 200) {
          setAyahs(quranData.data[0].ayahs);

          const tafsirMap: TafsirsRecord = {};
          tafsirData.data[0].ayahs.forEach((t: TafsirAyah) => {
            tafsirMap[t.numberInSurah] = t.text;
          });
          setTafsirs(tafsirMap);
        } else {
          setError("حدث خطأ أثناء جلب البيانات من الخادم.");
        }
      } catch (err) {
        setError("تعذر الاتصال بالخادم. تأكد من اتصالك بالإنترنت.");
      } finally {
        setLoading(false);
      }
    };

    fetchData();

    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
      }
    };
  }, [surahId, surahMeta]);

  const saveFontSize = (size: number) => {
    setFontSize(size);
    localStorage.setItem("quranFontSize", size.toString());
  };

  const toggleTafsir = (numberInSurah: number) => {
    setExpandedTafsirs((prev) => ({
      ...prev,
      [numberInSurah]: !prev[numberInSurah],
    }));
  };

  const playAudio = (globalAyahNumber: number) => {
    if (playingAyah === globalAyahNumber && audioRef.current) {
      audioRef.current.pause();
      setPlayingAyah(null);
      return;
    }

    if (audioRef.current) {
      audioRef.current.pause();
    }

    const audio = new Audio(
      `https://cdn.islamic.network/quran/audio/128/ar.alafasy/${globalAyahNumber}.mp3`,
    );
    audioRef.current = audio;

    audio.play();
    setPlayingAyah(globalAyahNumber);

    audio.onended = () => {
      setPlayingAyah(null);
      // Auto play next? Could be added here
    };
  };

  if (!surahMeta) {
    return (
      <PageTransition className="p-4 md:p-8">
        <div className="py-20 text-center text-muted-foreground bg-card rounded-3xl border border-dashed border-border">
          {error || "السورة غير متوفرة."}
          <div className="mt-4">
            <button
              onClick={() => navigate("/quran")}
              className="text-primary hover:underline"
            >
              العودة للفهرس
            </button>
          </div>
        </div>
      </PageTransition>
    );
  }

  return (
    <PageTransition className="p-4 md:p-8 flex flex-col gap-6 pb-24 md:pb-8">
      {/* Controls Bar */}
      <div className="sticky top-0 z-40 bg-background/80 backdrop-blur-md border-b border-border pb-4 pt-2 -mx-4 px-4 md:mx-0 md:px-0 flex flex-col md:flex-row md:items-center justify-between gap-4 rounded-b-2xl md:rounded-none">
        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate("/quran")}
            className="p-2 bg-card rounded-full shadow-sm border border-border hover:bg-muted"
          >
            <ArrowRight className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-2xl font-bold font-cairo">
              سورة {surahMeta.name}
            </h1>
            <p className="text-xs text-muted-foreground">
              {surahMeta.revelationType} • {surahMeta.ayahCount} آية
            </p>
          </div>
        </div>

        <div className="flex items-center gap-4 bg-card px-4 py-2 rounded-xl border border-border shadow-sm">
          <div className="flex items-center gap-2">
            <span className="text-sm font-bold text-muted-foreground">
              الخط:
            </span>
            <input
              type="range"
              min="16"
              max="48"
              value={fontSize}
              onChange={(e) => saveFontSize(parseInt(e.target.value))}
              className="w-24 accent-primary"
            />
          </div>
          <div className="w-px h-6 bg-border"></div>
          <button
            onClick={() => setShowAllTafsir(!showAllTafsir)}
            className={`text-sm font-bold px-3 py-1 rounded-md transition-colors ${showAllTafsir ? "bg-primary/10 text-primary" : "hover:bg-muted"}`}
          >
            التفسير {showAllTafsir ? "إخفاء" : "إظهار"}
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="space-y-4">
        {loading ? (
          <div className="flex flex-col items-center justify-center py-20">
            <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
            <p className="mt-4 text-muted-foreground">جاري تحميل الآيات...</p>
          </div>
        ) : error ? (
          <div className="py-20 text-center text-red-500 bg-red-50 dark:bg-red-900/10 rounded-2xl border border-red-200 dark:border-red-900/30">
            {error}
          </div>
        ) : (
          <>
            {/* Basmalah */}
            {surahId !== 1 && surahId !== 9 && (
              <div className="py-8 text-center">
                <span className="font-cairo text-3xl md:text-4xl text-foreground">
                  بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ
                </span>
              </div>
            )}

            {/* Ayahs */}
            {ayahs.map((ayah) => {
              const isExpanded =
                showAllTafsir || expandedTafsirs[ayah.numberInSurah];
              const isPlaying = playingAyah === ayah.number;
              // Clean up the text: if it's not Fatiha and starts with basmalah, remove it for display
              let text = ayah.text;
              if (
                surahId !== 1 &&
                ayah.numberInSurah === 1 &&
                text.startsWith("بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ ")
              ) {
                text = text.replace(
                  "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ ",
                  "",
                );
              }

              return (
                <div
                  key={ayah.number}
                  className={`bg-card border transition-colors rounded-2xl p-6 ${isPlaying ? "border-primary shadow-md" : "border-border"}`}
                >
                  <div className="flex flex-col md:flex-row gap-6">
                    <div
                      className="flex-1 text-center md:text-right leading-loose"
                      style={{ fontSize: `${fontSize}px` }}
                    >
                      <span className="font-cairo text-foreground">{text}</span>
                      <span className="inline-flex items-center justify-center w-10 h-10 rounded-full border-2 border-accent text-accent text-sm mx-3 align-middle font-bold">
                        {ayah.numberInSurah}
                      </span>
                    </div>

                    <div className="flex flex-row md:flex-col justify-center items-center gap-3 shrink-0 border-t md:border-t-0 md:border-r border-border pt-4 md:pt-0 md:pr-4">
                      <button
                        onClick={() => playAudio(ayah.number)}
                        className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${
                          isPlaying
                            ? "bg-primary text-primary-foreground shadow-lg shadow-primary/30 scale-110"
                            : "bg-muted text-muted-foreground hover:bg-primary/10 hover:text-primary"
                        }`}
                      >
                        {isPlaying ? (
                          <Pause className="w-4 h-4" />
                        ) : (
                          <Play className="w-4 h-4 ml-0.5" />
                        )}
                        {isPlaying && (
                          <span className="absolute w-12 h-12 border-2 border-primary rounded-full animate-ping opacity-20"></span>
                        )}
                      </button>

                      {!showAllTafsir && (
                        <button
                          onClick={() => toggleTafsir(ayah.numberInSurah)}
                          className="text-xs font-bold text-muted-foreground hover:text-primary flex flex-col items-center gap-1"
                        >
                          تفسير
                          {isExpanded ? (
                            <ChevronUp className="w-3 h-3" />
                          ) : (
                            <ChevronDown className="w-3 h-3" />
                          )}
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Tafsir Expandable Area */}
                  {isExpanded && tafsirs[ayah.numberInSurah] && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      className="mt-6 pt-4 border-t border-border/50 text-muted-foreground text-sm md:text-base leading-relaxed bg-muted/30 rounded-xl p-4"
                    >
                      <p>
                        <span className="font-bold text-foreground mr-1">
                          التفسير الميسر:
                        </span>{" "}
                        {tafsirs[ayah.numberInSurah]}
                      </p>
                    </motion.div>
                  )}
                </div>
              );
            })}
          </>
        )}
      </div>
    </PageTransition>
  );
}
