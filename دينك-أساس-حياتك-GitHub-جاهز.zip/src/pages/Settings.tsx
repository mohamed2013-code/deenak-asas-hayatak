import { PageTransition } from "../components/PageTransition";
import { ThemeToggle } from "../components/ThemeToggle";
import { Bell, Globe, Volume2, Calendar, Shield, CircleHelp, ChevronLeft, BookOpen } from "lucide-react";
import { useState } from "react";

export default function Settings() {
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [fontSize, setFontSize] = useState(50); // percentage 0-100

  const SettingRow = ({ icon: Icon, title, description, control }: any) => (
    <div className="flex items-center justify-between py-4 border-b border-border/50 last:border-0">
      <div className="flex items-center gap-4">
        <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center text-primary">
          <Icon className="w-5 h-5" />
        </div>
        <div>
          <p className="font-bold text-foreground">{title}</p>
          {description && <p className="text-sm text-muted-foreground">{description}</p>}
        </div>
      </div>
      <div>{control}</div>
    </div>
  );

  return (
    <PageTransition className="p-4 md:p-8 flex flex-col gap-6 max-w-3xl mx-auto w-full pb-24 md:pb-8">
      <div>
        <h1 className="text-3xl font-bold text-foreground mb-2">الإعدادات</h1>
        <p className="text-muted-foreground">تخصيص تجربتك في التطبيق</p>
      </div>

      <div className="space-y-6 mt-4">
        {/* Appearance Group */}
        <section>
          <h2 className="text-lg font-bold text-muted-foreground mb-3 px-2">المظهر والعرض</h2>
          <div className="bg-card border border-border rounded-3xl p-2 px-4 shadow-sm">
            <SettingRow 
              icon={Globe} 
              title="مظهر التطبيق" 
              description="تغيير بين الوضع الفاتح والداكن"
              control={<ThemeToggle />}
            />
            <SettingRow 
              icon={BookOpen} 
              title="حجم خط القراءة" 
              description="تكبير أو تصغير نص القرآن والأذكار"
              control={
                <div className="w-32 md:w-48 flex items-center gap-2">
                  <span className="text-sm">أ</span>
                  <input 
                    type="range" 
                    min="0" max="100" 
                    value={fontSize} 
                    onChange={(e) => setFontSize(parseInt(e.target.value))}
                    className="w-full h-2 bg-muted rounded-lg appearance-none cursor-pointer accent-primary"
                  />
                  <span className="text-lg font-bold">أ</span>
                </div>
              }
            />
          </div>
        </section>

        {/* Notifications Group */}
        <section>
          <h2 className="text-lg font-bold text-muted-foreground mb-3 px-2">التنبيهات والصوت</h2>
          <div className="bg-card border border-border rounded-3xl p-2 px-4 shadow-sm">
            <SettingRow 
              icon={Bell} 
              title="تنبيهات الصلاة والأذكار" 
              description="تلقي إشعارات بمواعيد الصلاة والأذكار اليومية"
              control={
                <button 
                  onClick={() => setNotificationsEnabled(!notificationsEnabled)}
                  className={`w-12 h-6 rounded-full transition-colors relative ${notificationsEnabled ? 'bg-primary' : 'bg-muted'}`}
                >
                  <span className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${notificationsEnabled ? 'left-1' : 'right-1'}`}></span>
                </button>
              }
            />
            <SettingRow 
              icon={Volume2} 
              title="المؤثرات الصوتية" 
              description="أصوات النقرات في السبحة والتنقل"
              control={
                <button 
                  onClick={() => setSoundEnabled(!soundEnabled)}
                  className={`w-12 h-6 rounded-full transition-colors relative ${soundEnabled ? 'bg-primary' : 'bg-muted'}`}
                >
                  <span className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${soundEnabled ? 'left-1' : 'right-1'}`}></span>
                </button>
              }
            />
          </div>
        </section>

        {/* General Group */}
        <section>
          <h2 className="text-lg font-bold text-muted-foreground mb-3 px-2">عام</h2>
          <div className="bg-card border border-border rounded-3xl p-2 px-4 shadow-sm">
            <SettingRow 
              icon={Calendar} 
              title="التقويم الهجري" 
              control={<ChevronLeft className="w-5 h-5 text-muted-foreground" />}
            />
            <SettingRow 
              icon={Shield} 
              title="الخصوصية والأمان" 
              control={<ChevronLeft className="w-5 h-5 text-muted-foreground" />}
            />
            <SettingRow 
              icon={CircleHelp} 
              title="المساعدة والدعم" 
              control={<ChevronLeft className="w-5 h-5 text-muted-foreground" />}
            />
          </div>
        </section>
        
        <div className="text-center py-6">
          <p className="text-muted-foreground text-sm">الإصدار ١.٠.٠</p>
          <p className="text-muted-foreground text-xs mt-1">صُنع بحب 🤍</p>
        </div>
      </div>
    </PageTransition>
  );
}
