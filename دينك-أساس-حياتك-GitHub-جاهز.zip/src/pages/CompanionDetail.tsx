import { useNavigate, useParams } from "react-router-dom";
import { PageTransition } from "../components/PageTransition";
import { companions } from "../data/companions";
import { IslamicPattern } from "../components/IslamicPattern";
import { ArrowRight, Star, Heart, Award, Shield, BookOpen } from "lucide-react";
import { motion } from "framer-motion";

export default function CompanionDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  
  const companion = companions.find(c => c.id === id);

  if (!companion) {
    return (
      <div className="p-8 text-center flex flex-col items-center justify-center min-h-[50vh]">
        <h2 className="text-2xl font-bold mb-4">لم يتم العثور على الصحابي</h2>
        <button onClick={() => navigate('/companions')} className="text-primary hover:underline">
          العودة للقائمة
        </button>
      </div>
    );
  }

  return (
    <PageTransition className="p-4 md:p-8 flex flex-col gap-6 pb-24 md:pb-8">
      <button 
        onClick={() => navigate(-1)}
        className="self-start flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors bg-card px-4 py-2 rounded-full shadow-sm border border-border"
      >
        <ArrowRight className="w-4 h-4" />
        <span>الرجوع</span>
      </button>

      {/* Hero Section */}
      <div className="bg-card border border-border rounded-3xl p-8 relative overflow-hidden shadow-sm">
        <IslamicPattern opacity={0.03} />
        
        <div className="relative z-10 flex flex-col items-center text-center">
          <div className="inline-block px-4 py-1.5 rounded-full bg-primary/10 text-primary text-sm font-bold mb-6">
            {companion.category}
          </div>
          
          <h1 className="text-4xl md:text-5xl font-black mb-3 font-cairo">
            {companion.name} <span className="text-2xl text-muted-foreground font-normal">رضي الله عنه</span>
          </h1>
          
          <p className="text-lg md:text-xl text-foreground font-medium mb-2">
            {companion.title}
          </p>
          
          <p className="text-sm md:text-base text-muted-foreground mb-6 max-w-2xl">
            {companion.fullName}
          </p>

          <div className="bg-muted px-6 py-2 rounded-xl text-sm font-bold text-muted-foreground">
            توفي سنة: {companion.deathYear}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Story */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-card border border-border rounded-3xl p-6 md:p-8"
        >
          <h2 className="text-2xl font-bold flex items-center gap-3 mb-4 text-foreground">
            <div className="w-10 h-10 rounded-full bg-blue-500/10 flex items-center justify-center text-blue-500">
              <BookOpen className="w-5 h-5" />
            </div>
            قصة إسلامه
          </h2>
          <p className="text-muted-foreground leading-relaxed text-lg">
            {companion.conversionStory}
          </p>
        </motion.div>

        {/* Virtues */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-card border border-border rounded-3xl p-6 md:p-8"
        >
          <h2 className="text-2xl font-bold flex items-center gap-3 mb-4 text-foreground">
            <div className="w-10 h-10 rounded-full bg-emerald-500/10 flex items-center justify-center text-emerald-500">
              <Heart className="w-5 h-5" />
            </div>
            مناقبه وفضله
          </h2>
          <p className="text-muted-foreground leading-relaxed text-lg">
            {companion.virtues}
          </p>
        </motion.div>

        {/* Key Moments */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-card border border-border rounded-3xl p-6 md:p-8 lg:col-span-2"
        >
          <h2 className="text-2xl font-bold flex items-center gap-3 mb-6 text-foreground">
            <div className="w-10 h-10 rounded-full bg-accent/20 flex items-center justify-center text-accent">
              <Award className="w-5 h-5" />
            </div>
            أبرز مواقفه
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {companion.keyMoments.map((moment, idx) => (
              <div key={idx} className="flex gap-4 p-4 rounded-2xl bg-muted/50">
                <div className="w-8 h-8 rounded-full bg-background flex items-center justify-center text-primary font-bold shrink-0 shadow-sm">
                  {idx + 1}
                </div>
                <p className="text-muted-foreground leading-relaxed text-base pt-1">
                  {moment}
                </p>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Legacy */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-primary text-primary-foreground rounded-3xl p-6 md:p-8 lg:col-span-2 relative overflow-hidden"
        >
          <IslamicPattern opacity={0.1} />
          <h2 className="text-2xl font-bold flex items-center gap-3 mb-4 relative z-10">
            <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center text-white">
              <Shield className="w-5 h-5" />
            </div>
            أثره ومكانته
          </h2>
          <p className="text-primary-foreground/90 leading-relaxed text-lg relative z-10">
            {companion.legacy}
          </p>
        </motion.div>
      </div>
    </PageTransition>
  );
}
