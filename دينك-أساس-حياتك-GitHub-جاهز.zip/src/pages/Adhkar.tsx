import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Copy, Heart, Share2, CheckCircle2, RotateCcw } from "lucide-react";
import { PageTransition } from "../components/PageTransition";
import { IslamicPattern } from "../components/IslamicPattern";
import { adhkarCategories, adhkarItems } from "../data/adhkar";

type ZikrItem = {
  id: number;
  text: string;
  count: number;
  reference: string;
  hint?: string;
};

function ZikrCard({ zikr }: { zikr: ZikrItem }) {
  const [current, setCurrent] = useState(0);
  const [liked, setLiked] = useState(false);
  const [copied, setCopied] = useState(false);
  const done = current >= zikr.count;

  const handleCount = () => {
    if (!done) setCurrent((p) => p + 1);
  };

  const handleReset = () => setCurrent(0);

  const handleCopy = () => {
    navigator.clipboard.writeText(zikr.text).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    });
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({ text: zikr.text });
    } else {
      handleCopy();
    }
  };

  const progress = Math.min((current / zikr.count) * 100, 100);

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className={`relative overflow-hidden rounded-2xl border shadow-sm transition-all ${
        done
          ? "border-primary/40 bg-primary/5"
          : "border-border bg-card hover:shadow-md"
      }`}
    >
      <IslamicPattern opacity={0.03} />

      <div className="relative z-10 p-6">
        {/* Zikr text */}
        <p className="text-xl md:text-2xl font-medium leading-loose text-center text-foreground py-2">
          {zikr.text}
        </p>

        {/* Reference */}
        <p className="text-sm text-muted-foreground text-center mt-2">
          {zikr.reference}
        </p>

        {/* Progress bar */}
        <div className="mt-4 h-1.5 w-full bg-muted rounded-full overflow-hidden">
          <motion.div
            className="h-full bg-primary rounded-full"
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.3 }}
          />
        </div>

        {/* Footer row */}
        <div className="flex items-center justify-between mt-4">
          {/* Action buttons */}
          <div className="flex gap-2">
            <button
              onClick={handleCopy}
              title="نسخ"
              className={`p-2 rounded-full transition-colors ${
                copied
                  ? "bg-primary/10 text-primary"
                  : "hover:bg-muted text-muted-foreground"
              }`}
            >
              <Copy className="w-4 h-4" />
            </button>
            <button
              onClick={() => setLiked((p) => !p)}
              title="إضافة للمفضلة"
              className={`p-2 rounded-full transition-colors ${
                liked
                  ? "bg-red-50 dark:bg-red-900/20 text-red-500"
                  : "hover:bg-muted text-muted-foreground"
              }`}
            >
              <Heart className="w-4 h-4" fill={liked ? "currentColor" : "none"} />
            </button>
            <button
              onClick={handleShare}
              title="مشاركة"
              className="p-2 rounded-full hover:bg-muted text-muted-foreground transition-colors"
            >
              <Share2 className="w-4 h-4" />
            </button>
            {current > 0 && (
              <button
                onClick={handleReset}
                title="إعادة"
                className="p-2 rounded-full hover:bg-muted text-muted-foreground transition-colors"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Counter button */}
          {done ? (
            <div className="flex items-center gap-2 text-primary font-bold">
              <CheckCircle2 className="w-5 h-5" />
              <span>اكتمل</span>
            </div>
          ) : (
            <button
              onClick={handleCount}
              className="bg-primary text-primary-foreground px-5 py-2 rounded-full font-bold text-sm transition-transform active:scale-95 hover:opacity-90 shadow-sm"
            >
              {current} / {zikr.count}
            </button>
          )}
        </div>
      </div>
    </motion.div>
  );
}

export default function Adhkar() {
  const [activeCategory, setActiveCategory] = useState<string>(
    adhkarCategories[0].id
  );

  const currentItems: ZikrItem[] = adhkarItems[activeCategory] ?? [];

  return (
    <PageTransition className="p-4 md:p-8 flex flex-col gap-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-foreground mb-2">الأذكار</h1>
        <p className="text-muted-foreground">
          وَالذَّاكِرِينَ اللَّهَ كَثِيرًا وَالذَّاكِرَاتِ أَعَدَّ اللَّهُ لَهُم مَّغْفِرَةً وَأَجْرًا عَظِيمًا
        </p>
      </div>

      {/* Category tabs */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
        {adhkarCategories.map((cat) => {
          const isActive = activeCategory === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`relative overflow-hidden p-4 rounded-2xl flex flex-col items-center justify-center gap-2 transition-all text-sm font-bold ${
                isActive
                  ? "bg-primary text-primary-foreground shadow-lg shadow-primary/20 scale-[1.02]"
                  : "bg-card text-muted-foreground border border-border hover:border-primary/30 hover:shadow-md"
              }`}
            >
              {isActive && <IslamicPattern opacity={0.1} />}
              <span className="relative z-10">{cat.title}</span>
              <span
                className={`relative z-10 text-xs px-2 py-0.5 rounded-full ${
                  isActive
                    ? "bg-white/20 text-white"
                    : "bg-muted text-muted-foreground"
                }`}
              >
                {cat.count} ذكر
              </span>
            </button>
          );
        })}
      </div>

      {/* Zikr cards */}
      <div className="pb-24 md:pb-8">
        <AnimatePresence mode="wait">
          {currentItems.length > 0 ? (
            <motion.div
              key={activeCategory}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.25 }}
              className="space-y-4"
            >
              {currentItems.map((item) => (
                <ZikrCard key={item.id} zikr={item} />
              ))}
            </motion.div>
          ) : (
            <motion.div
              key="empty"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="py-20 text-center text-muted-foreground bg-card rounded-3xl border border-dashed border-border flex flex-col items-center justify-center gap-4"
            >
              <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center">
                <span className="text-3xl opacity-50">🤲</span>
              </div>
              <p>سيتم إضافة أذكار لهذا القسم قريباً</p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </PageTransition>
  );
}
