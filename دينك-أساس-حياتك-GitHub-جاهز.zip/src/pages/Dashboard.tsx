import { PageTransition } from "../components/PageTransition";
import { StatCard } from "../components/StatCard";
import { Heart, BookOpen, Calendar, Award, Flame, TrendingUp } from "lucide-react";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Cell
} from "recharts";
import { IslamicPattern } from "../components/IslamicPattern";

const weeklyData = [
  { name: 'السبت', adhkar: 45, quran: 10 },
  { name: 'الأحد', adhkar: 52, quran: 12 },
  { name: 'الاثنين', adhkar: 38, quran: 8 },
  { name: 'الثلاثاء', adhkar: 65, quran: 15 },
  { name: 'الأربعاء', adhkar: 48, quran: 10 },
  { name: 'الخميس', adhkar: 55, quran: 14 },
  { name: 'الجمعة', adhkar: 85, quran: 25 },
];

export default function Dashboard() {
  return (
    <PageTransition className="p-4 md:p-8 flex flex-col gap-8 pb-24 md:pb-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-foreground mb-2">لوحة المستخدم</h1>
          <p className="text-muted-foreground">تابع تقدمك في العبادات اليومية</p>
        </div>
        
        <div className="bg-card border border-border px-4 py-2 rounded-xl flex items-center gap-3 shadow-sm">
          <div className="w-10 h-10 bg-orange-500/10 rounded-full flex items-center justify-center text-orange-500">
            <Flame className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs text-muted-foreground font-medium">سلسلة الأيام</p>
            <p className="font-bold">١٤ يوم متتالٍ</p>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard 
          title="الأذكار المكتملة اليوم" 
          value="٢٤" 
          icon={<Heart className="w-6 h-6" />} 
          trend="↑ ١٢٪ عن الأمس"
          trendUp={true}
        />
        <StatCard 
          title="صفحات القرآن" 
          value="١٠" 
          icon={<BookOpen className="w-6 h-6" />} 
          trend="مستمر على الورد"
          trendUp={true}
        />
        <StatCard 
          title="تسبيحات اليوم" 
          value="٣٣٠" 
          icon={<Award className="w-6 h-6" />} 
        />
        <StatCard 
          title="أيام الالتزام بالشهر" 
          value="٢٢" 
          icon={<Calendar className="w-6 h-6" />} 
        />
      </div>

      <div className="grid lg:grid-cols-3 gap-6 mt-4">
        {/* Chart Section */}
        <div className="lg:col-span-2 bg-card border border-border rounded-3xl p-6 shadow-sm">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-lg font-bold">نشاطك خلال الأسبوع</h3>
            <div className="flex items-center gap-4 text-sm font-medium">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-primary"></span>
                <span>الأذكار</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-accent"></span>
                <span>القرآن</span>
              </div>
            </div>
          </div>
          
          <div className="h-72 w-full" dir="ltr">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={weeklyData}
                margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
              >
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                <XAxis 
                  dataKey="name" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }} 
                  dy={10}
                />
                <YAxis 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 12 }} 
                />
                <Tooltip 
                  cursor={{ fill: 'hsl(var(--muted)/0.5)' }}
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))', 
                    borderColor: 'hsl(var(--border))',
                    borderRadius: '12px',
                    boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'
                  }}
                  itemStyle={{ fontWeight: 'bold' }}
                />
                <Bar dataKey="adhkar" name="الأذكار" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} maxBarSize={40} />
                <Bar dataKey="quran" name="القرآن" fill="hsl(var(--accent))" radius={[4, 4, 0, 0]} maxBarSize={40} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Goals & Achievements */}
        <div className="space-y-6">
          <div className="bg-primary text-primary-foreground rounded-3xl p-6 shadow-lg shadow-primary/20 relative overflow-hidden">
            <IslamicPattern opacity={0.1} />
            <div className="relative z-10">
              <div className="flex items-center gap-3 mb-4">
                <TrendingUp className="w-6 h-6 text-accent" />
                <h3 className="text-lg font-bold">هدف اليوم</h3>
              </div>
              <p className="text-primary-foreground/80 text-sm mb-4">أنت قريب جداً من إتمام وردك اليومي للقرآن الكريم</p>
              
              <div className="space-y-2">
                <div className="flex justify-between text-sm font-medium">
                  <span>التقدم</span>
                  <span>٨٠٪</span>
                </div>
                <div className="h-2.5 w-full bg-primary-foreground/20 rounded-full overflow-hidden">
                  <div className="h-full bg-accent rounded-full w-[80%] relative">
                    <div className="absolute inset-0 bg-white/20 w-full animate-[shimmer_2s_infinite]"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-card border border-border rounded-3xl p-6 shadow-sm">
            <h3 className="text-lg font-bold mb-4">أحدث الإنجازات</h3>
            <div className="space-y-4">
              {[
                { title: "ختم سورة البقرة", date: "اليوم", icon: "👑", color: "bg-amber-500/10 text-amber-600" },
                { title: "المحافظة على صلاة الفجر", date: "أمس", icon: "🌅", color: "bg-blue-500/10 text-blue-600" },
                { title: "١٠٠٠ تسبيحة", date: "منذ ٣ أيام", icon: "📿", color: "bg-emerald-500/10 text-emerald-600" },
              ].map((item, i) => (
                <div key={i} className="flex items-center gap-4 pb-4 border-b border-border/50 last:border-0 last:pb-0">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center text-lg ${item.color}`}>
                    {item.icon}
                  </div>
                  <div>
                    <p className="font-bold text-sm">{item.title}</p>
                    <p className="text-xs text-muted-foreground">{item.date}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </PageTransition>
  );
}
