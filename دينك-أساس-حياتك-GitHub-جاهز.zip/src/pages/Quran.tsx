import { PageTransition } from "../components/PageTransition";
import { SurahCard } from "../components/SurahCard";
import { surahs } from "../data/surahs";
import { Search } from "lucide-react";
import { useState } from "react";

export default function Quran() {
  const [searchTerm, setSearchTerm] = useState("");

  const filteredSurahs = surahs.filter(
    (surah) =>
      surah.name.includes(searchTerm) ||
      surah.id.toString().includes(searchTerm),
  );

  return (
    <PageTransition className="p-4 md:p-8 flex flex-col gap-6">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-foreground mb-2">
            القرآن الكريم
          </h1>
          <p className="text-muted-foreground">
            اقرأ وارتقِ، فإن منزلتك عند آخر آية تقرؤها
          </p>
        </div>

        <div className="relative max-w-sm w-full">
          <div className="absolute inset-y-0 right-3 flex items-center pointer-events-none">
            <Search className="w-5 h-5 text-muted-foreground" />
          </div>
          <input
            type="text"
            placeholder="ابحث عن سورة..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-card border border-border rounded-xl py-3 pr-10 pl-4 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all"
            dir="rtl"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-4">
        {filteredSurahs.length > 0 ? (
          filteredSurahs.map((surah, index) => (
            <SurahCard key={surah.id} surah={surah} index={index} />
          ))
        ) : (
          <div className="col-span-full py-12 text-center text-muted-foreground bg-card rounded-2xl border border-dashed border-border">
            لم يتم العثور على نتائج مطابقة لبحثك
          </div>
        )}
      </div>
    </PageTransition>
  );
}
