import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { ThemeProvider } from "./components/ThemeProvider";
import { Layout } from "./components/Layout";
import { lazy, Suspense } from "react";
// Pages lazy loaded
const Home = lazy(() => import("./pages/Home"));
const Quran = lazy(() => import("./pages/Quran"));
const SurahView = lazy(() => import("./pages/SurahView"));
const Adhkar = lazy(() => import("./pages/Adhkar"));
const Adiyah = lazy(() => import("./pages/Adiyah"));
const PrayerTimes = lazy(() => import("./pages/PrayerTimes"));
const Qibla = lazy(() => import("./pages/Qibla"));
const Tasbih = lazy(() => import("./pages/Tasbih"));
const Mood = lazy(() => import("./pages/Mood"));
const Dashboard = lazy(() => import("./pages/Dashboard"));
const Settings = lazy(() => import("./pages/Settings"));
const About = lazy(() => import("./pages/About"));
const Contact = lazy(() => import("./pages/Contact"));
const Prophets = lazy(() => import("./pages/Prophets"));
const ProphetDetail = lazy(() => import("./pages/ProphetDetail"));
const Companions = lazy(() => import("./pages/Companions"));
const CompanionDetail = lazy(() => import("./pages/CompanionDetail"));
const Hadith = lazy(() => import("./pages/Hadith"));

const queryClient = new QueryClient();

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider
        attribute="class"
        defaultTheme="light"
        enableSystem={false}
      >
        <div
          dir="rtl"
          className="font-sans antialiased text-foreground bg-background"
        >
          <BrowserRouter basename={import.meta.env.BASE_URL.replace(/\/$/, "")}>
            <Layout>
              <Suspense
                fallback={
                  <div className="min-h-screen flex items-center justify-center">
                    <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin" />
                  </div>
                }
              >
                <Routes>
                  <Route path="/" element={<Home />} />
                  <Route path="/quran" element={<Quran />} />
                  <Route path="/quran/surah/:id" element={<SurahView />} />
                  <Route path="/adhkar" element={<Adhkar />} />
                  <Route path="/adiyah" element={<Adiyah />} />
                  <Route path="/prophets" element={<Prophets />} />
                  <Route path="/prophets/:id" element={<ProphetDetail />} />
                  <Route path="/companions" element={<Companions />} />
                  <Route path="/companions/:id" element={<CompanionDetail />} />
                  <Route path="/prayer-times" element={<PrayerTimes />} />
                  <Route path="/qibla" element={<Qibla />} />
                  <Route path="/tasbih" element={<Tasbih />} />
                  <Route path="/mood" element={<Mood />} />
                  <Route path="/dashboard" element={<Dashboard />} />
                  <Route path="/hadiths" element={<Hadith />} />
                  <Route path="/settings" element={<Settings />} />
                  <Route path="/about" element={<About />} />
                  <Route path="/contact" element={<Contact />} />
                  <Route path="*" element={<Navigate to="/" replace />} />
                </Routes>
              </Suspense>
            </Layout>
          </BrowserRouter>
        </div>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
