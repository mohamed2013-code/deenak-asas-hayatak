import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Prophet } from "../types";
import { BookOpen, Star } from "lucide-react";

export function ProphetCard({ prophet, index }: { prophet: Prophet; index: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05 }}
    >
      <Link 
        to={`/prophets/${prophet.id}`}
        className="block h-full bg-card border border-border rounded-2xl overflow-hidden hover:shadow-lg hover:border-primary/30 transition-all group"
      >
        <div className="bg-gradient-to-bl from-primary/10 to-transparent p-5 flex items-center justify-between border-b border-border/50">
          <div className="w-12 h-12 bg-card rounded-xl shadow-sm flex items-center justify-center font-bold text-xl text-primary border border-primary/10">
            {prophet.order}
          </div>
          <div className="text-left">
            <h3 className="text-2xl font-bold text-foreground font-cairo group-hover:text-primary transition-colors">
              {prophet.name}
            </h3>
            <p className="text-sm text-accent font-medium mt-1">{prophet.title}</p>
          </div>
        </div>
        
        <div className="p-5 space-y-3">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Star className="w-4 h-4 text-primary" />
            <span>المكان: <span className="font-semibold text-foreground">{prophet.nation}</span></span>
          </div>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <BookOpen className="w-4 h-4 text-primary" />
            <span>ذُكر <span className="font-semibold text-foreground">{prophet.quranMentions}</span> مرة</span>
          </div>
        </div>
      </Link>
    </motion.div>
  );
}
