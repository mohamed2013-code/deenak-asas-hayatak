import { ReactNode } from "react";
import { Sidebar } from "./Sidebar";
import { MobileNav } from "./MobileNav";

export const Layout = ({ children }: { children: ReactNode }) => {
  return (
    <div className="flex min-h-[100dvh] bg-background text-foreground font-sans selection:bg-primary selection:text-primary-foreground">
      <Sidebar />
      <main className="flex-1 w-full pb-16 md:pb-0 overflow-x-hidden relative">
        <div className="max-w-4xl mx-auto min-h-[100dvh] flex flex-col">
          {children}
        </div>
      </main>
      <MobileNav />
    </div>
  );
};
