export const IslamicPattern = ({ className = "", opacity = 0.05 }: { className?: string, opacity?: number }) => (
  <svg 
    className={`absolute inset-0 pointer-events-none w-full h-full object-cover ${className}`} 
    style={{ opacity }}
    xmlns="http://www.w3.org/2000/svg" 
    viewBox="0 0 100 100" 
    fill="currentColor"
  >
    <path d="M50 0L60 40L100 50L60 60L50 100L40 60L0 50L40 40Z" />
    <path d="M25 25L35 45L50 50L35 55L25 75L45 65L50 50L55 65Z" opacity="0.5" />
    <path d="M75 25L55 45L50 50L55 55L75 75L65 65L50 50L65 45Z" opacity="0.5" />
  </svg>
);
