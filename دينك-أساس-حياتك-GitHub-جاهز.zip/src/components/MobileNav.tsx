import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import {
  Home,
  BookOpen,
  Heart,
  Menu,
  X,
  Clock,
  Compass,
  Hand,
  Smile,
  LayoutDashboard,
  Settings,
  Info,
  Mail,
  Users,
  Star,
  BookMarked,
} from "lucide-react";
import { ThemeToggle } from "./ThemeToggle";
import { AnimatePresence, motion } from "framer-motion";

const primaryNavItems = [
  { path: "/", label: "الرئيسية", icon: Home },
  { path: "/hadiths", label: "الأحاديث", icon: BookMarked },
  { path: "/quran", label: "القرآن", icon: BookOpen },
  { path: "/adhkar", label: "الأذكار", icon: Heart },
  { path: "/prayer-times", label: "الصلاة", icon: Clock },
];

const allOtherItems = [
  { path: "/adiyah", label: "الأدعية", icon: Hand },
  { path: "/prophets", label: "الأنبياء والرسل", icon: Users },
  { path: "/companions", label: "الصحابة الكرام", icon: Star },
  { path: "/qibla", label: "القبلة", icon: Compass },
  { path: "/tasbih", label: "السبحة الإلكترونية", icon: Heart },
  { path: "/mood", label: "بماذا تشعر؟", icon: Smile },
  { path: "/dashboard", label: "لوحة المستخدم", icon: LayoutDashboard },
  { path: "/settings", label: "الإعدادات", icon: Settings },
  { path: "/about", label: "من نحن", icon: Info },
  { path: "/contact", label: "اتصل بنا", icon: Mail },
];

export const MobileNav = () => {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  return (
    <>
      {/* Bottom Bar */}
      <div className="fixed bottom-0 left-0 right-0 bg-card/90 backdrop-blur-lg border-t border-border p-2 md:hidden z-40">
        <div className="flex items-center justify-around">
          {primaryNavItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex flex-col items-center gap-1 p-2 rounded-xl transition-all ${
                  isActive
                    ? "text-primary font-bold"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="text-[10px]">{item.label}</span>
              </Link>
            );
          })}
          <button
            onClick={() => setIsOpen(true)}
            className="flex flex-col items-center gap-1 p-2 text-muted-foreground hover:text-foreground"
          >
            <Menu className="w-5 h-5" />
            <span className="text-[10px]">المزيد</span>
          </button>
        </div>
      </div>

      {/* Slide-out Menu */}
      <AnimatePresence>
        {isOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsOpen(false)}
              className="fixed inset-0 bg-black/50 z-50 md:hidden backdrop-blur-sm"
            />
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 200 }}
              className="fixed inset-y-0 right-0 w-4/5 max-w-sm bg-card border-l border-border p-6 z-50 md:hidden flex flex-col justify-between overflow-y-auto"
            >
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-xl bg-primary/10 flex items-center justify-center text-primary font-bold">
                      ط
                    </div>
                    <span className="font-bold text-lg text-foreground">
                      طمئن قلبك
                    </span>
                  </div>
                  <button
                    onClick={() => setIsOpen(false)}
                    className="p-2 rounded-xl hover:bg-muted text-muted-foreground"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="space-y-1">
                  {allOtherItems.map((item) => {
                    const Icon = item.icon;
                    const isActive = location.pathname === item.path;
                    return (
                      <Link
                        key={item.path}
                        to={item.path}
                        onClick={() => setIsOpen(false)}
                        className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${
                          isActive
                            ? "bg-primary text-primary-foreground font-bold"
                            : "text-muted-foreground hover:bg-muted hover:text-foreground"
                        }`}
                      >
                        <Icon className="w-4 h-4" />
                        <span>{item.label}</span>
                      </Link>
                    );
                  })}
                </div>
              </div>

              <div className="pt-4 border-t border-border flex items-center justify-between">
                <span className="text-xs text-muted-foreground">المظهر</span>
                <ThemeToggle />
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
};
