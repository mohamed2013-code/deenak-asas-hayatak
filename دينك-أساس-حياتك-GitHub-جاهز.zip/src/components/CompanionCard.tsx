import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Companion } from "../types";

export function CompanionCard({ companion, index }: { companion: Companion; index: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay: index * 0.03 }}
    >
      <Link 
        to={`/companions/${companion.id}`}
        className="block h-full bg-card border border-border rounded-2xl p-5 hover:shadow-md hover:border-primary/30 transition-all group"
      >
        <div className="flex items-start justify-between mb-4">
          <h3 className="text-xl font-bold text-foreground group-hover:text-primary transition-colors">
            {companion.name}
          </h3>
          <span className="bg-muted text-muted-foreground text-xs px-2.5 py-1 rounded-full font-bold">
            {companion.category}
          </span>
        </div>
        
        <p className="text-sm text-accent font-bold mb-2">{companion.title}</p>
        <p className="text-xs text-muted-foreground line-clamp-2 leading-relaxed">
          {companion.fullName}
        </p>
      </Link>
    </motion.div>
  );
}
