import { Clock, MapPin } from "lucide-react";
import { motion } from "framer-motion";
import { IslamicPattern } from "./IslamicPattern";

interface PrayerCardProps {
  name: string;
  time: string;
  isNext?: boolean;
}

export const PrayerCard = ({ name, time, isNext = false }: PrayerCardProps) => {
  return (
    <motion.div
      whileHover={{ y: -2 }}
      className={`relative overflow-hidden rounded-2xl p-4 transition-all duration-300 border ${
        isNext 
          ? "bg-primary text-primary-foreground border-primary shadow-lg shadow-primary/20 scale-[1.02]" 
          : "bg-card text-foreground border-border hover:border-primary/30 hover:shadow-md"
      }`}
    >
      {isNext && <IslamicPattern className="text-primary-foreground" opacity={0.1} />}
      
      <div className="relative z-10 flex flex-col items-center justify-center space-y-2">
        <span className={`text-sm font-medium ${isNext ? "text-primary-foreground/90" : "text-muted-foreground"}`}>
          {name}
        </span>
        <span className={`text-2xl font-bold tracking-tight ${isNext ? "text-accent" : ""}`}>
          {time}
        </span>
      </div>
      
      {isNext && (
        <div className="absolute top-2 left-2 flex h-2 w-2">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-accent opacity-75"></span>
          <span className="relative inline-flex rounded-full h-2 w-2 bg-accent"></span>
        </div>
      )}
    </motion.div>
  );
};
