import { ReactNode } from "react";
import { Link, useLocation } from "react-router-dom";
import {
  Home,
  BookOpen,
  Heart,
  Clock,
  Compass,
  Hand,
  Smile,
  LayoutDashboard,
  Settings,
  Info,
  Mail,
  Users,
  Star,
  BookMarked,
} from "lucide-react";
import { ThemeToggle } from "./ThemeToggle";

const navItems = [
  { path: "/", label: "الرئيسية", icon: Home },
  { path: "/hadiths", label: "الأحاديث النبوية", icon: BookMarked },
  { path: "/quran", label: "القرآن الكريم", icon: BookOpen },
  { path: "/adhkar", label: "الأذكار", icon: Heart },
  { path: "/adiyah", label: "الأدعية", icon: Hand },
  { path: "/prophets", label: "الأنبياء والرسل", icon: Users },
  { path: "/companions", label: "الصحابة الكرام", icon: Star },
  { path: "/prayer-times", label: "مواقيت الصلاة", icon: Clock },
  { path: "/qibla", label: "القبلة", icon: Compass },
  { path: "/tasbih", label: "السبحة الإلكترونية", icon: Heart },
  { path: "/mood", label: "بماذا تشعر؟", icon: Smile },
  { path: "/dashboard", label: "لوحة المستخدم", icon: LayoutDashboard },
];

const secondaryNavItems = [
  { path: "/settings", label: "الإعدادات", icon: Settings },
  { path: "/about", label: "من نحن", icon: Info },
  { path: "/contact", label: "اتصل بنا", icon: Mail },
];

export const Sidebar = () => {
  const location = useLocation();

  return (
    <aside className="w-64 bg-card border-l border-border min-h-screen p-4 flex flex-col justify-between hidden md:flex">
      <div className="space-y-6">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-3 px-2 py-1">
          <div className="w-10 h-10 rounded-2xl bg-primary/10 flex items-center justify-center text-primary font-bold text-xl">
            ط
          </div>
          <div>
            <h1 className="font-bold text-lg leading-none text-foreground">
              طمئن قلبك
            </h1>
            <p className="text-xs text-muted-foreground mt-1">
              تطبيق إسلامي شامل
            </p>
          </div>
        </Link>

        {/* Navigation */}
        <nav className="space-y-1">
          <div className="text-xs font-semibold text-muted-foreground px-3 mb-2">
            القائمة الرئيسية
          </div>
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${
                  isActive
                    ? "bg-primary text-primary-foreground font-bold shadow-md shadow-primary/20"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground"
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{item.label}</span>
              </Link>
            );
          })}
        </nav>

        <div className="w-full h-px bg-border my-2" />

        {/* Secondary Navigation */}
        <nav className="space-y-1">
          <div className="text-xs font-semibold text-muted-foreground px-3 mb-2">
            أخرى
          </div>
          {secondaryNavItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${
                  isActive
                    ? "bg-primary text-primary-foreground font-bold"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground"
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{item.label}</span>
              </Link>
            );
          })}
        </nav>
      </div>

      {/* Footer */}
      <div className="pt-4 border-t border-border flex items-center justify-between">
        <span className="text-xs text-muted-foreground">المظهر</span>
        <ThemeToggle />
      </div>
    </aside>
  );
};
