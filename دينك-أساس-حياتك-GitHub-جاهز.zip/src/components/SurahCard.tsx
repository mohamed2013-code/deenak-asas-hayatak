import { Link } from "react-router-dom";
import { BookOpen } from "lucide-react";
import { Surah } from "../types";
import { motion } from "framer-motion";
import { IslamicPattern } from "./IslamicPattern";

interface SurahCardProps {
  surah: Surah;
  index: number;
}

export const SurahCard = ({ surah, index }: SurahCardProps) => {
  return (
    <Link to={`/quran/surah/${surah.id}`}>
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: index * 0.05 }}
        whileHover={{ y: -2 }}
        className="group relative overflow-hidden rounded-2xl bg-card border border-border p-4 transition-all duration-300 hover:border-primary/40 hover:shadow-md flex items-center justify-between"
      >
        <div className="flex items-center gap-4">
          <div className="relative w-12 h-12 rounded-xl bg-muted/50 flex items-center justify-center text-lg font-bold text-primary group-hover:bg-primary group-hover:text-primary-foreground transition-colors overflow-hidden">
            <IslamicPattern opacity={0.1} />
            <span className="relative z-10">{surah.id}</span>
          </div>
          <div>
            <h3 className="text-xl font-bold text-foreground mb-1 group-hover:text-primary transition-colors">{surah.name}</h3>
            <div className="flex items-center gap-3 text-xs text-muted-foreground">
              <span className="flex items-center gap-1">
                <BookOpen className="w-3 h-3" />
                {surah.ayahCount} آية
              </span>
              <span className="w-1 h-1 rounded-full bg-border"></span>
              <span>{surah.revelationType}</span>
            </div>
          </div>
        </div>
        
        <div className="text-3xl font-black text-muted/30 group-hover:text-accent/20 transition-colors pointer-events-none select-none">
          {surah.name}
        </div>
      </motion.div>
    </Link>
  );
};
