import { useState } from "react";
import { Heart, RefreshCcw } from "lucide-react";
import { motion } from "framer-motion";

interface DhikrCardProps {
  text: string;
  count: number;
  reference?: string;
  hint?: string;
}

export const DhikrCard = ({ text, count, reference, hint }: DhikrCardProps) => {
  const [currentCount, setCurrentCount] = useState(count);
  const isCompleted = currentCount === 0;

  const handleTap = () => {
    if (currentCount > 0) {
      setCurrentCount(prev => prev - 1);
      // Optional: simulate haptic feedback
      if (window.navigator && window.navigator.vibrate) {
        window.navigator.vibrate(50);
      }
    }
  };

  const handleReset = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentCount(count);
  };

  return (
    <motion.div
      layout
      onClick={handleTap}
      whileTap={!isCompleted ? { scale: 0.98 } : {}}
      className={`relative overflow-hidden rounded-2xl border p-6 transition-all duration-300 cursor-pointer ${
        isCompleted 
          ? "bg-muted/50 border-border/50 opacity-70" 
          : "bg-card border-border hover:border-primary/40 hover:shadow-md"
      }`}
    >
      <div className="absolute top-4 left-4">
        {isCompleted ? (
          <button 
            onClick={handleReset}
            className="p-2 bg-background rounded-full text-muted-foreground hover:text-foreground shadow-sm z-10 relative"
          >
            <RefreshCcw className="w-4 h-4" />
          </button>
        ) : (
          <div className="w-12 h-12 rounded-full bg-primary/10 border border-primary/20 flex items-center justify-center text-lg font-bold text-primary shadow-inner">
            {currentCount}
          </div>
        )}
      </div>

      <div className="mt-8 space-y-4">
        <p className="text-xl md:text-2xl font-medium leading-loose text-center text-foreground font-cairo">
          {text}
        </p>
        
        {hint && (
          <p className="text-sm text-center text-muted-foreground dir-ltr font-sans">
            {hint}
          </p>
        )}
        
        {reference && (
          <div className="flex items-center justify-center gap-2 mt-4 text-xs text-muted-foreground/80 bg-muted/30 py-1.5 px-3 rounded-full w-fit mx-auto">
            <Heart className="w-3 h-3 text-accent" />
            <span>{reference}</span>
          </div>
        )}
      </div>

      {/* Completion overlay */}
      {isCompleted && (
        <div className="absolute inset-0 flex items-center justify-center bg-background/40 backdrop-blur-[1px] pointer-events-none">
          <motion.div 
            initial={{ scale: 0.5, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-primary text-primary-foreground px-4 py-2 rounded-full font-bold shadow-lg shadow-primary/30 flex items-center gap-2"
          >
            <Heart className="w-4 h-4 text-accent" fill="currentColor" />
            <span>اكتمل</span>
          </motion.div>
        </div>
      )}
    </motion.div>
  );
};
