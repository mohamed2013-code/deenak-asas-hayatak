export interface Surah {
  id: number;
  name: string;
  ayahCount: number;
  revelationType: 'مكية' | 'مدنية';
}

export interface AdhkarCategory {
  id: string;
  title: string;
  count: number;
}

export interface DuaCategory {
  id: string;
  title: string;
}

export interface Prophet {
  id: string;
  name: string;
  title: string;        
  order: number;        
  period: string;       
  nation: string;       
  birthplace: string;   
  quranMentions: number; 
  lineage: string;       
  upbringing: string;    
  mission: string;       
  miracles: string[];    
  lessons: string[];     
  mainVerse: string;     
  mainVerseRef: string;  
}

export interface Companion {
  id: string;
  name: string;
  fullName: string;     
  title: string;        
  category: 'الخلفاء الراشدون' | 'العشرة المبشرون' | 'أمهات المؤمنين' | 'القادة والفاتحون' | 'العلماء والرواة' | 'الصحابيات';
  conversionStory: string;  
  virtues: string;          
  keyMoments: string[];     
  legacy: string;           
  deathYear: string;        
}
