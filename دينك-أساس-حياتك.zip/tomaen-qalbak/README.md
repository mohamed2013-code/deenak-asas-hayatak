# طمئن قلبك — دينك أساس حياتك

A standalone Vite + React website prepared for free deployment.

## Run locally

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```

## Free deployment

This project can be deployed as a static site on Cloudflare Pages or another static host.

Before submitting the sitemap to Google, replace `YOUR-SITE-URL` in `public/robots.txt` and `public/sitemap.xml` with the real website address.
